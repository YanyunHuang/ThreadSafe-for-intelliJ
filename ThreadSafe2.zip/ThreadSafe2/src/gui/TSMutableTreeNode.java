package gui;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

/**
 * Created by huangyanyun on 6/18/17.
 */
public class TSMutableTreeNode extends DefaultMutableTreeNode {

    public TSMutableTreeNode(Object userObject) {
        super(userObject, true);
    }

    @Override
    public String toString() {

        if (userObject == null) {
            return "";
        }else if(userObject instanceof TreeNodeData) {
            if(isLeaf()){
                return ((TreeNodeData) userObject).getName();
            }else{
                if(((TreeNodeData) userObject).getContent() instanceof ArrayList){
                    return ((TreeNodeData) userObject).getName() +  "  ("
                            + ((ArrayList)((TreeNodeData) userObject).getContent()).size() + ")";
                }
            }
        }
        return userObject.toString();
    }


}
