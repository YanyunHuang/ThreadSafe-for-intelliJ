package gui;

import com.intellij.ui.treeStructure.treetable.TreeTableModel;
import com.intellij.util.ui.ColumnInfo;
import model.xml.Finding;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

/**
 * Created by huangyanyun on 6/10/17.
 */
public class TSTreeColumnInfo extends ColumnInfo {

    public TSTreeColumnInfo(final String name) {
        super(name);
    }

    public final Class getColumnClass() {
        return TreeTableModel.class;
    }

    public final Object valueOf(final Object object) {

        Object value = "deafult";
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) object;
        if (node.getUserObject() instanceof Finding) {
            value = ((Finding) node.getUserObject()).getInfo().getMessage().getValue();
        } else if (node.getUserObject() instanceof String) {
            value = (String) node.getUserObject();
        } else if (node.getUserObject() instanceof ArrayList) {
            value = ((Finding) ((ArrayList) node.getUserObject()).get(0)).getInfo().getMessage().getValue() +
                    "   (" + ((ArrayList) node.getUserObject()).size() + ")";
        }
        return value;
    }

}
