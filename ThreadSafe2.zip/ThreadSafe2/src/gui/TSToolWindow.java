package gui;

import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.MultiLineLabelUI;
import com.intellij.ui.treeStructure.treetable.*;
import com.intellij.util.ui.ColumnInfo;
import com.intellij.util.ui.tree.TreeUtil;
import intellij.Tools;
import manager.PluginManager;
import model.ui.enums.DisplayType;
import model.ui.enums.TreeItemType;
import model.xml.Finding;
import model.xml.TSClass;
import model.xml.TSLocation;
import model.ui.enums.GroupType;
import model.xml.enums.FindingType;
import model.xml.enums.Severity;
import util.DebugController;
import util.CommonUtils;
import util.TSTreeUtil;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.font.TextAttribute;
import java.util.*;

/**
 * Created by huangyanyun on 6/3/17.
 */
public class TSToolWindow {

    private static TSToolWindow instance;
    private JPanel mainPanel;
    private JScrollPane leftPanel;
    private JPanel rightPanel;
    private JLabel blockerValue;
    private JLabel criticalValue;
    private JLabel majorValue;
    private JLabel minorValue;
    private JLabel infoValue;
    private JLabel totalValue;
    private TSTreeTableView findingTree;
    private JLabel typeString;
    private JLabel msgValue;
    private JLabel fileName;
    private JPanel locations;
    private JLabel hierarchyLink;
    private JLabel ruleLink;
    private JLabel severity;
    private JLabel category;
    private JLabel type;
    private JScrollPane right1;
    private JScrollPane right2;

    private TSMutableTreeNode root;
    private ColumnInfo[] column;
    private ListTreeTableModelOnColumns registersModel;
    private ListSelectionListener listSelectionListener = new ListSelectionListener(){
        @Override
        public void valueChanged(ListSelectionEvent e) {

            if (!e.getValueIsAdjusting()) {
                DebugController.debug("============click on tree============");
                ListSelectionModel model = findingTree.getSelectionModel();
                int lead = model.getLeadSelectionIndex();
                if(lead != -1){
                    TreeTableTree tree = findingTree.getTree();
                    if(tree != null){
                        TreePath pathForRow = tree.getPathForRow(lead);
                        if(pathForRow != null){
                            final TSMutableTreeNode node = (TSMutableTreeNode) pathForRow.getLastPathComponent();

                            if (node.isLeaf()) {
                                singleClickOnLeaf(node.getUserObject());
                            } else {
                                singleClickOnNode(node.getUserObject());
                            }
                        }

                    }

                }
            }
        }

    };

    private MouseListener mouseListener = new MouseListener(){


        @Override
        public void mouseClicked(MouseEvent e) {
            if(e.getClickCount() == 2){
                doubleClickOnItem();
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    };

    private void doubleClickOnItem(){
        DebugController.debug("============doubleClickOnItem============");
        ListSelectionModel model = findingTree.getSelectionModel();
        int lead = model.getLeadSelectionIndex();
        if(lead != -1){
            TreeTableTree tree = findingTree.getTree();
            TreePath pathForRow = tree.getPathForRow(lead);
            final TSMutableTreeNode node = (TSMutableTreeNode) pathForRow.getLastPathComponent();

            if (node.isLeaf()) {
                if(node.getUserObject() instanceof TreeNodeData){
                    Object content = ((TreeNodeData) node.getUserObject()).getContent();
                    if(content instanceof Finding){
                        navigateToSourceFile((Finding) content);
                    }
                }
            }
        }
    }

    public static TSToolWindow getInstance(){
        if(instance == null){
            instance = new TSToolWindow();
        }
        return instance;
    }

    public void updateTree(Project project, Object list, GroupType group, DisplayType dis){

        DebugController.debug("============updateTree============");
//        root.removeAllChildren();
//        registersModel.reload();

        updateTreeTable(project, list, group, dis);

        this.mainPanel.setVisible(true);
        this.leftPanel.setVisible(true);
        this.rightPanel.setVisible(true);
        this.right1.setVisible(false);
        this.right2.setVisible(false);
        this.mainPanel.validate();

    }

    private void createUIComponents() {
        DebugController.debug("============createUIComponents============");
        createTree();
    }

    private void initUI(Finding finding){
        hierarchyLink.setForeground(Color.blue);
        ruleLink.setForeground(Color.blue);

        hierarchyLink.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                PluginManager.getInstance().callHierarchy(e, finding);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                addUnderline(hierarchyLink);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                removeUnderline(hierarchyLink);
            }
        });

        ruleLink.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                PluginManager.getInstance().openUrl(finding);
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                addUnderline(ruleLink);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                removeUnderline(ruleLink);
            }
        });
    }

    private void createTree(){
        DebugController.debug("============createTree============");

        column = TSTreeUtil.getColume();
        TreeNodeData rootData = new TreeNodeData("root",0, null);
        root = new TSMutableTreeNode(rootData);
        registersModel = new ListTreeTableModelOnColumns(root, column);
        this.findingTree = new TSTreeTableView(registersModel);

    }

    public JPanel getMainPanel() {
        return mainPanel;
    }

    private void $$$setupUI$$$() {
        createUIComponents();
    }

    public void collapse(){
        TreeUtil.collapseAll(this.findingTree.getTree(), 1);
    }

    public void expand(){
        TreeUtil.expandAll(this.findingTree.getTree());
    }

    private void updateTreeTable(Project project, Object list, GroupType type, DisplayType dis) {
        DebugController.debug("============updateTreeTable============");

        root.removeAllChildren();
        switch (type) {
            case Type:
                showTypeTreeTable((ArrayList<Finding>) list);
                break;
            case Severity:
                showSeverityTreeTable((ArrayList<Finding>) list);
                break;
            case Project:
                showProjectTreeTable(project, (LinkedHashMap<Module, ArrayList<Finding>>) list);
                break;
            case Resource:
                showResourceTreeTable((ArrayList<Finding>) list);
                break;
            case No_grouping:
                showNoGroupingTreeTable((ArrayList<Finding>) list);
                break;
            default:
                showTypeTreeTable((ArrayList<Finding>) list);
                break;
        }
        registersModel.reload();
        this.findingTree.getSelectionModel().addListSelectionListener(listSelectionListener);
        this.findingTree.addMouseListener(mouseListener);
    }

    private void showTypeTreeTable(ArrayList<Finding> list){

        DebugController.debug("============showTypeTreeTable============");

        if ((list != null) && (list.size() != 0)) {
            HashMap<FindingType, ArrayList<Finding>> map = CommonUtils.sortFindingsByType(list);
            Iterator it = map.entrySet().iterator();
            while (it.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry)it.next();

                ArrayList<Finding> findings = (ArrayList<Finding>)pair.getValue();
                TreeNodeData typeData = new TreeNodeData(
                        (CommonUtils.getTypeName(findings.get(0).getType())), findings.size(), findings);

                TSMutableTreeNode node = new TSMutableTreeNode(typeData);

                for (int i = 0; i < findings.size(); i ++){
//                Icon icon = addIcon(findings.get(i));
                    TreeNodeData leaf = new TreeNodeData(findings.get(i).getInfo().getMessage().getValue(), -1, findings.get(i));
                    TSMutableTreeNode child = new TSMutableTreeNode(leaf);
                    node.add(child);
                }
                root.add(node);
                it.remove(); // avoids a ConcurrentModificationException
            }
        }
    }

    private void showSeverityTreeTable(ArrayList<Finding> list){
        DebugController.debug("============showSeverityTreeTable============");

        if ((list != null) && (list.size() != 0)) {
            HashMap<Severity, ArrayList<Finding>> map = CommonUtils.sortFindingsBySeverity(list);

            Iterator it = map.entrySet().iterator();
            while (it.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry)it.next();

                ArrayList<Finding> findings = (ArrayList<Finding>)pair.getValue();
                TreeNodeData nodeContent = new TreeNodeData(
                        (CommonUtils.getTypeSeverity(findings.get(0).getType()).toString()), findings.size(), findings);

                TSMutableTreeNode node = new TSMutableTreeNode(nodeContent);

                for (int i = 0; i < findings.size(); i ++){
                    TreeNodeData leaf = new TreeNodeData(
                            findings.get(i).getInfo().getMessage().getValue(),findings.size(),  findings.get(i));
                    TSMutableTreeNode child = new TSMutableTreeNode(leaf);
                    node.add(child);
                }
                root.add(node);
                it.remove(); // avoids a ConcurrentModificationException
            }
        }
    }

    private void showProjectTreeTable(Project project, LinkedHashMap<Module, ArrayList<Finding>> hash){
        DebugController.debug("============showProjectTreeTable============");

        Iterator it = hash.entrySet().iterator();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            Module pro = (Module) pair.getKey();
            ArrayList<Finding> list = (ArrayList<Finding>) pair.getValue();
            if((list != null) && (list.size() > 0)){
                TSMutableTreeNode projectNode  = new TSMutableTreeNode(
                        new TreeNodeData(pro.getName(), 0, null, TreeItemType.Project));
                TSMutableTreeNode srcNode = new TSMutableTreeNode(new TreeNodeData("src",0, null, TreeItemType.Folder));
                projectNode.add(srcNode);
                root.add(projectNode);

                for (int index = 0; index < list.size(); index ++){
                    String path = list.get(index).getLocations().get(0).getPath();
                    String[] paths = path.split("/");
                    TSMutableTreeNode parentNode = srcNode;
                    for(int j = 2; j < paths.length; j ++){

                        String childName = paths[j];
                        int childCount = parentNode.getChildCount();
                        boolean isLeaf = (j == (paths.length - 1))? true: false;
                        //If no child node, just add a new child
                        if(childCount == 0){
                            TSMutableTreeNode newChild = addNewLeafOrNode(parentNode, list.get(index), isLeaf, childName);
                            parentNode = newChild;

                        }else{
                            boolean exist = false;
                            for (int m = 0; m < childCount; m ++){
                                TSMutableTreeNode existChild = (TSMutableTreeNode)parentNode.getChildAt(m);
                                if(existChild.getUserObject() instanceof TreeNodeData){
                                    if(((TreeNodeData) existChild.getUserObject()).getName().equals(childName)){
                                        exist = true;
                                        if(isLeaf){
                                            addingLeaf(existChild, list.get(index));
                                        }else{
                                            parentNode = existChild;
                                        }
                                        break;
                                    }
                                }
                            }
                            if(!exist){
                                TSMutableTreeNode newChild = addNewLeafOrNode(parentNode, list.get(index), isLeaf, childName);
                                parentNode = newChild;
                            }
                        }
                    }
                }
            }
        }
    }

    private TSMutableTreeNode addNewLeafOrNode(TSMutableTreeNode parent, Finding finding, boolean isLeaf, String name){

        TSMutableTreeNode newChildNode = new TSMutableTreeNode(new TreeNodeData(name, 1, null, TreeItemType.Package));
        parent.add(newChildNode);
        if(isLeaf){
            ((TreeNodeData)newChildNode.getUserObject()).setItemType(TreeItemType.File);
            addingLeaf(newChildNode, finding);

        }
        return newChildNode;

    }

    private void addingLeaf(TSMutableTreeNode parent, Finding finding){
        parent.add(new TSMutableTreeNode(new TreeNodeData(finding.getInfo().getMessage().getValue(),-1, finding)));
        ((TreeNodeData)parent.getUserObject()).setNumber(((TreeNodeData)parent.getUserObject()).getNumber() + 1);
        updateParentNode(parent, finding);

    }

    private void updateParentNode(TSMutableTreeNode parent, Finding finding){

        while(parent!= null){
            if(parent.getUserObject() instanceof TreeNodeData){
                if(((TreeNodeData) parent.getUserObject()).getContent() instanceof ArrayList){
                    ArrayList list = (ArrayList)((TreeNodeData) parent.getUserObject()).getContent();
                    list.add(finding);
                    ((TreeNodeData) parent.getUserObject()).setNumber(list.size());
                } else if(((TreeNodeData) parent.getUserObject()).getContent() == null){
                    ArrayList<Finding> list = new ArrayList<Finding>();
                    list.add(finding);
                    ((TreeNodeData) parent.getUserObject()).setContent(list);
                    ((TreeNodeData) parent.getUserObject()).setNumber(list.size());
                }
            }
            parent = (TSMutableTreeNode)parent.getParent();
        }
    }

    private void showResourceTreeTable(ArrayList<Finding> list){
        DebugController.debug("============showResourceTreeTable============");

        if ((list != null) && (list.size() != 0)) {
            HashMap<String, ArrayList<Finding>> map = CommonUtils.sortFindingsByResource(list);
            Iterator it = map.entrySet().iterator();
            while (it.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry)it.next();

                ArrayList<Finding> findings = (ArrayList<Finding>)pair.getValue();
                TreeNodeData nodeContent = new TreeNodeData(findings.get(0).getLocations().get(0).getFileName(), findings.size(), findings);

                TSMutableTreeNode node = new TSMutableTreeNode(nodeContent);

                for (int i = 0; i < findings.size(); i ++){
//                Icon icon = addIcon(findings.get(i));
                    TreeNodeData leaf = new TreeNodeData(findings.get(i).getInfo().getMessage().getValue(), -1, findings.get(i));
                    TSMutableTreeNode child = new TSMutableTreeNode(leaf);
                    node.add(child);
                }
                root.add(node);
                it.remove(); // avoids a ConcurrentModificationException
            }
        }
    }

    private void showNoGroupingTreeTable(ArrayList<Finding> list){
        DebugController.debug("============showNoGroupingTreeTable============");

        if ((list != null) && (list.size() != 0)) {
            for(int index = 0; index < list.size(); index ++){
                TreeNodeData leaf = new TreeNodeData(list.get(index).getInfo().getMessage().getValue(), -1, list.get(index));
                TSMutableTreeNode child = new TSMutableTreeNode(leaf);
                root.add(child);
            }
        }
    }

    private void singleClickOnNode(Object node){
        DebugController.debug("============singleClickOnNode============");

        if(node instanceof TreeNodeData){
            if(((TreeNodeData) node).getContent() == null){
                showAlert("Oooops, the node is broken");
            }
            ArrayList<Finding> findings = (ArrayList<Finding>)((TreeNodeData) node).getContent();

            clearSeverityInfo();
            blockerValue.setText(CommonUtils.getSeverityNum(Severity.Blocker, findings) + "");
            criticalValue.setText(CommonUtils.getSeverityNum(Severity.Critical, findings) + "");
            majorValue.setText(CommonUtils.getSeverityNum(Severity.Major, findings) + "");
            minorValue.setText(CommonUtils.getSeverityNum(Severity.Minor, findings) + "");
            infoValue.setText(CommonUtils.getSeverityNum(Severity.Info, findings) + "");
            totalValue.setText(findings.size() + "");

            this.rightPanel.setVisible(true);
            this.right1.setVisible(true);
            this.right2.setVisible(false);
            this.mainPanel.revalidate();
        }else{
            showAlert("Oooops, the node has no info");
        }
    }

    private void clearSeverityInfo(){
        blockerValue.setText("0");
        criticalValue.setText("0");
        majorValue.setText("0");
        minorValue.setText("0");
        infoValue.setText("0");
        totalValue.setText("0");
    }

    private void singleClickOnLeaf(Object node){
        DebugController.debug("============singleClickOnLeaf============");
        if(node instanceof TreeNodeData) {
            if(((TreeNodeData) node).getContent() == null){
                showAlert("Oooops, the leaf node is broken");
            }
            Finding finding = (Finding) ((TreeNodeData) node).getContent();

//            String html_start = "<html><p style=\\\"width:100px\\\">";
            String html_start = "<html><p>";
            String html_end = "</p></html>";
//            int width = (int)this.typeString.getParent().getParent().getParent().getPreferredSize().getWidth();
//            this.typeString.setText(String.format("<html><div style=\"width:%dpx;\">%s</div><html>", width, CommonUtils.getTypeName(finding.getType())));
            this.typeString.setUI(new MultiLineLabelUI());
            this.typeString.setText(html_start + CommonUtils.getTypeName(finding.getType()) + html_end);
//            this.msgValue.setText(String.format("<html><div WIDTH=%d>%s</div><html>", width, finding.getInfo().getMessage().getValue()));
            this.msgValue.setUI(new MultiLineLabelUI());
            this.msgValue.setText(html_start + finding.getInfo().getMessage().getValue());
            this.fileName.setText(html_start + finding.getLocations().get(0).getFileName());
            this.severity.setText(CommonUtils.getTypeSeverity(finding.getType()).toString());
            this.severity.setIcon(new ImageIcon(this.getClass().getClassLoader().getResource(CommonUtils.createSeverityIcon(finding.getType()))));
            this.category.setText(CommonUtils.getTypeCategory(finding.getType()).toString());
            this.type.setText(html_start + finding.getType().toString());

            createProblemLocation(finding);
            initUI(finding);

            this.rightPanel.setVisible(true);
            this.right1.setVisible(false);
            this.right2.setVisible(true);
            this.mainPanel.revalidate();
        }else{
            showAlert("Oooops, the leaf node is broken");
            return;
        }
    }


    private void createProblemLocation(Finding finding){
        ArrayList<TSLocation> locationsInfo = finding.getLocations();
        this.locations.removeAll();
        if((locationsInfo == null) || (locationsInfo.size() == 0)){
            showAlert("Oooops, the leaf node has no location information");
            return;
        }

        for (int i = 0; i < locationsInfo.size(); i++){
            if(locationsInfo.get(i) instanceof TSClass){
                break;
            }
            String lineStr = locationsInfo.get(i).getLine();
            if (lineStr == null){
                showAlert("Oooops, no line number.");
            }
            if(Integer.parseInt(lineStr) < 1){
                int lineInt = Tools.getFieldLineNumber(locationsInfo.get(i));
                lineInt += 1;
                lineStr = lineInt + "";
            }
            final int line = Integer.parseInt(lineStr);
            String label = locationsInfo.get(i).getLabel();
            String labelString = "";
            if((label == null) || (label.toString().equals("catch"))){
                labelString = "Problem location";
            }else if (label.toString().equals("guard_field")){
                continue;

            }else{
                labelString = CommonUtils.getLabelString(label);
            }

            JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JLabel lineLabel = new JLabel(line + "");
            lineLabel.setForeground(Color.blue);
            lineLabel.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    navigateToSourceFile(finding, line + "");
                }

                @Override
                public void mousePressed(MouseEvent e) {}

                @Override
                public void mouseReleased(MouseEvent e) {}

                @Override
                public void mouseEntered(MouseEvent e) {
                    addUnderline(lineLabel);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    removeUnderline(lineLabel);
                }
            });
            JLabel description = new JLabel(labelString);

            p.add(lineLabel);
            p.add(description);

            this.locations.setLayout(new GridLayout(0,1));
            this.locations.add(p);
        }
    }

    private void addUnderline(JLabel label){
        Font font = label.getFont();
        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
        label.setFont(font.deriveFont(attributes));
    }

    private void removeUnderline(JLabel label){
        Font font = label.getFont();
        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, -1);
        label.setFont(font.deriveFont(attributes));

    }

    private void navigateToSourceFile(Finding finding){
        String line = finding.getLocations().get(0).getLine();
        navigateToSourceFile(finding, line);
    }

    private void navigateToSourceFile(Finding finding, String lineNum){
        PluginManager.getInstance().openEditorToolWindow(finding.getLocations().get(0), lineNum);
    }

    private void showAlert(String alert){
        DebugController.debug(alert);

    }

    public void clear() {
        this.mainPanel.setVisible(true);
        this.leftPanel.setVisible(true);
        this.rightPanel.setVisible(true);
        this.right1.setVisible(false);
        this.right2.setVisible(false);
        this.mainPanel.validate();
    }
}
