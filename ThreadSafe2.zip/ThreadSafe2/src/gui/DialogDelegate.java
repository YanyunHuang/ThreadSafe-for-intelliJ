package gui;

import threadsafe.ThreadSafeCallable;

/**
 * Created by huangyanyun on 7/10/17.
 */
public interface DialogDelegate {

    void showInBackground();
    void showInFront();
    void onCanceled();
    void onDetail();
    void onBackground();
}
