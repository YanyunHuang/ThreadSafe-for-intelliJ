package gui;

import threadsafe.ThreadSafeCallable;

/**
 * Created by huangyanyun on 7/10/17.
 */
public interface ThreadDelegate {

    void start();
    void run(ThreadSafeCallable.ThreadSafeAnswer answer);
    void finish();
    void err(ThreadSafeCallable.ThreadSafeAnswer answer);
}
