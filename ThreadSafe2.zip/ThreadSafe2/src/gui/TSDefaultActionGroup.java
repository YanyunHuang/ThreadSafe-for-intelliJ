package gui;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DefaultActionGroup;

/**
 * Created by huangyanyun on 6/16/17.
 */
public class TSDefaultActionGroup extends DefaultActionGroup{

    public static TSDefaultActionGroup instance;

    @Override
    public void update(AnActionEvent event) {

//        Editor editor = event.getData(CommonDataKeys.EDITOR);
//        event.getPresentation().setVisible(true);
//        event.getPresentation().setEnabled(editor != null);
//        event.getPresentation().setIcon(AllIcons.General.Error);

    }

    public static TSDefaultActionGroup getInstance(){
        if (instance == null){
            instance = new TSDefaultActionGroup();
        }
        return instance;
    }


}
