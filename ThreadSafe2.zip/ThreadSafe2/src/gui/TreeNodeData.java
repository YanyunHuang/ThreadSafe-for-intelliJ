package gui;

import model.ui.enums.TreeItemType;

/**
 * Used to store node data
 * Created by huangyanyun on 6/21/17.
 */
public class TreeNodeData {

    public TreeNodeData(String name, int number, Object content){
        this(name, number, content, TreeItemType.Severity);
    }

    public TreeNodeData(String name, int number, Object content, TreeItemType itemType){
        this.name = name;
        this.number = number;
        this.content = content;
        this.itemType = itemType;
    }

    private String name;
    private Object content;

    // total leaf number, -1 for leaf
    private int number = -1;
    private TreeItemType itemType = TreeItemType.Severity;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getContent() {
        return content;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public TreeItemType getItemType() {
        return itemType;
    }

    public void setItemType(TreeItemType itemType) {
        this.itemType = itemType;
    }
}
