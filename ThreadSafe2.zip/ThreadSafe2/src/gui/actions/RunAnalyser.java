package gui.actions;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import manager.PluginManager;
import manager.TSEngineManager;

/**
 * Created by huangyanyun on 5/29/17.
 */
public class RunAnalyser extends AnAction {

    @Override
    public void actionPerformed(AnActionEvent e) {
        //Run analyser
        PluginManager.getInstance().runProject(e);
    }

}
