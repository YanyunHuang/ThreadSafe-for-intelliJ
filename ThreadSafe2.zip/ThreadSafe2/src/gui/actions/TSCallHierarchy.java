package gui.actions;

import com.intellij.ide.DataManager;
import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.actionSystem.ex.CheckboxAction;
import com.intellij.openapi.actionSystem.ex.CustomComponentAction;
import com.intellij.util.ui.UIUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.font.TextAttribute;
import java.util.Map;

/**
 * Created by huangyanyun on 6/26/17.
 */
public class TSCallHierarchy extends ToggleAction implements CustomComponentAction {

    @Override
    public boolean isSelected(AnActionEvent e) {
        return false;
    }

    @Override
    public void setSelected(AnActionEvent e, boolean state) {

    }

    @Override
    public JComponent createCustomComponent(Presentation presentation) {
        // this component cannot be stored right here because of action system architecture:
        // one action can be shown on multiple toolbars simultaneously
        JLabel label = new JLabel();
        label.setOpaque(false);

        label.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JCheckBox checkBox = (JCheckBox)e.getSource();
                ActionToolbar actionToolbar = UIUtil.getParentOfType(ActionToolbar.class, checkBox);
                DataContext dataContext =
                        actionToolbar != null ? actionToolbar.getToolbarDataContext() : DataManager.getInstance().getDataContext(checkBox);
                TSCallHierarchy.this.actionPerformed(AnActionEvent.createFromAnAction(TSCallHierarchy.this, null, ActionPlaces.UNKNOWN, dataContext));


            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                addUnderline(label);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                removeUnderline(label);
            }
        });
        updateCustomComponent(label, presentation);
        return label;
    }

    protected void updateCustomComponent(JLabel label, Presentation presentation) {
        label.setText(presentation.getText());
        label.setToolTipText(presentation.getDescription());
//        label.setMnemonic(presentation.getMnemonic());
        label.setDisplayedMnemonicIndex(presentation.getDisplayedMnemonicIndex());
//        label.setSelected(Boolean.TRUE.equals(presentation.getClientProperty(SELECTED_PROPERTY)));
        label.setEnabled(presentation.isEnabled());
        label.setVisible(presentation.isVisible());
    }

    private void addUnderline(JLabel label){
        Font font = label.getFont();
        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
        label.setFont(font.deriveFont(attributes));
    }

    private void removeUnderline(JLabel label){
        Font font = label.getFont();
        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, -1);
        label.setFont(font.deriveFont(attributes));

    }
}
