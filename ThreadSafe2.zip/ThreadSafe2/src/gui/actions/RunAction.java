package gui.actions;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import manager.PluginManager;
import manager.TSEngineManager;

import javax.swing.*;

/**
 * Created by huangyanyun on 6/16/17.
 */
public class RunAction extends AnAction {

    public RunAction(){

        super("Run analyser", "Run analyser", new ImageIcon("/icons/elcl16/runAll.png"));
    }

    @Override
    public void actionPerformed(AnActionEvent e) {
        PluginManager.getInstance().runAll(e);
    }
}
