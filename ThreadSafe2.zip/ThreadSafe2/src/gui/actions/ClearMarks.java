package gui.actions;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import manager.PluginManager;
import util.DebugController;

import javax.swing.*;

/**
 * Created by huangyanyun on 6/16/17.
 */
public class ClearMarks extends AnAction {

    public ClearMarks(){

        super("Clear Marks", "Clear", new ImageIcon("/icons/elcl16/runAll.png"));
    }

    @Override
    public void actionPerformed(AnActionEvent e) {

        DebugController.debug("ClearAction");
        PluginManager controller = PluginManager.getInstance();
        controller.clear();

    }
}
