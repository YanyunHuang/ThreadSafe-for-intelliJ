package gui.actions;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import manager.PluginManager;
import model.ui.enums.DisplayType;

import javax.swing.*;

/**
 * Created by huangyanyun on 6/16/17.
 */
public class ShowAllAction extends AnAction {

    public ShowAllAction(){

        super("Show all", "Show all", new ImageIcon("/icons/elcl16/runAll.png"));
    }

    @Override
    public void actionPerformed(AnActionEvent e) {
        PluginManager controller = PluginManager.getInstance();
        controller.changeDisplayType(DisplayType.All);
    }

//    public boolean displayTextInToolbar() {
//        return true;
//    }
}
