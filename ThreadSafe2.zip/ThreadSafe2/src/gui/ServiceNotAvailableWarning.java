package gui;

import com.intellij.openapi.project.Project;
import com.intellij.ui.treeStructure.treetable.ListTreeTableModelOnColumns;
import com.intellij.ui.treeStructure.treetable.TreeTableTree;
import com.intellij.util.ui.ColumnInfo;
import manager.PluginManager;
import model.ui.enums.DisplayType;
import model.ui.enums.GroupType;
import model.xml.Finding;
import model.xml.enums.FindingType;
import model.xml.enums.Severity;
import util.CommonUtils;
import util.TSTreeUtil;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by huangyanyun on 6/6/17.
 */
public class ServiceNotAvailableWarning {
    private JPanel mainPanel;
    private TSTreeTableView tree;
    private JLabel blockerValue;
    private JLabel criticalValue;
    private JLabel majorValue;
    private JLabel minorValue;
    private JLabel infoValue;
    private JLabel totalValue;
    private JLabel typeDescription;
    private JLabel msgValue;
    private JLabel sourceFile;
    private JPanel locationPanel;
    private JLabel callHierarchy;
    private JLabel ruleDescription;
    private JLabel severityDescription;
    private JLabel category;
    private JLabel typeEnum;
    private JPanel rightPanel;
    private JScrollPane right1;
    private JScrollPane right2;

    private TSMutableTreeNode root;
    private ColumnInfo[] column;
    private ListTreeTableModelOnColumns registersModel;
    private ListSelectionListener listSelectionListener = new ListSelectionListener(){
        @Override
        public void valueChanged(ListSelectionEvent e) {

            if (!e.getValueIsAdjusting()) {
                System.out.println("=============valueChanged==================");
                ListSelectionModel model = tree.getSelectionModel();
                int lead = model.getLeadSelectionIndex();
                if(lead != -1){
                    TreeTableTree jtree = tree.getTree();
                    TreePath pathForRow = jtree.getPathForRow(lead);
                    final TSMutableTreeNode node = (TSMutableTreeNode) pathForRow.getLastPathComponent();

                    if (node.isLeaf()) {
                        singleClickOnLeaf(node.getUserObject());
                    } else {
                        singleClickOnNode(node.getUserObject());
                    }
                }
            }
        }

    };

    private void createUIComponents() {
        createTree();
    }

    private void createTree(){

        column = TSTreeUtil.getColume();
        root = new TSMutableTreeNode("root");
//        setRoot(root);
        registersModel = new ListTreeTableModelOnColumns(root, column);
        this.tree = new TSTreeTableView(registersModel);

    }

    private static ServiceNotAvailableWarning instance;

    public static ServiceNotAvailableWarning getInstance(){
        if(instance == null){
            instance = new ServiceNotAvailableWarning();
        }
        return instance;
    }

    public void initUI(Project project, ArrayList<Finding> list, GroupType group, DisplayType dis){

        System.out.println("=============update==================");
        updateTreeTable(project, list, group, dis);

        this.mainPanel.setVisible(true);
        this.tree.setVisible(true);
        this.rightPanel.setVisible(true);
        this.right1.setVisible(false);
        this.right2.setVisible(false);
        this.mainPanel.validate();

    }

    private void updateTreeTable(Project project, ArrayList<Finding> list, GroupType type, DisplayType dis) {

        System.out.println("=============updateTreeTable==================");

        if ((list == null) || (list.size() == 0)) {
            return;
        }
        switch (type) {
            case Type:
                showTypeTreeTable(list);
                break;
            case Severity:
                showSeverityTreeTable(list);
                break;
            case Project:
                showProjectTreeTable(project, list);
                break;
            case Resource:
                showResourceTreeTable(list);
                break;
            case No_grouping:
                showNoGroupingTreeTable(list);
                break;
            default:
                showTypeTreeTable(list);
                break;
        }
    }

    private void showTypeTreeTable(ArrayList<Finding> list){

        System.out.println("=============showTypeTreeTable==================");

        root = new TSMutableTreeNode("root");

        HashMap<FindingType, ArrayList<Finding>> map = CommonUtils.sortFindingsByType(list);
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry)it.next();

            ArrayList<Finding> findings = (ArrayList<Finding>)pair.getValue();
            TSMutableTreeNode node = new TSMutableTreeNode(findings);

            for (int i = 0; i < findings.size(); i ++){
                TSMutableTreeNode child = new TSMutableTreeNode(findings.get(i));
                node.add(child);
            }
            root.add(node);
            it.remove(); // avoids a ConcurrentModificationException
        }

        ListTreeTableModelOnColumns model = new ListTreeTableModelOnColumns(root, column);

        this.tree.setModel(model);
        this.tree.setRootVisible(false);
        this.tree.getSelectionModel().addListSelectionListener(listSelectionListener);

    }

    private void showSeverityTreeTable(ArrayList<Finding> list){

        System.out.println("=============showSeverityTreeTable==================");

        root = new TSMutableTreeNode("root");

        HashMap<Severity, ArrayList<Finding>> map = CommonUtils.sortFindingsBySeverity(list);

        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry)it.next();

            ArrayList<Finding> findings = (ArrayList<Finding>)pair.getValue();
            TSMutableTreeNode node = new TSMutableTreeNode(findings);

            for (int i = 0; i < findings.size(); i ++){
                TSMutableTreeNode child = new TSMutableTreeNode(findings.get(i));
                node.add(child);
            }
            root.add(node);
            it.remove(); // avoids a ConcurrentModificationException
        }

        ListTreeTableModelOnColumns model = new ListTreeTableModelOnColumns(root, column);
        this.tree.setModel(model);
        this.tree.setRootVisible(false);

        this.tree.getSelectionModel().addListSelectionListener(listSelectionListener);
    }

    private void showProjectTreeTable(Project project, ArrayList<Finding> list){
        //TODO

    }

    private void showResourceTreeTable(ArrayList<Finding> list){
        //TODO
    }

    private void showNoGroupingTreeTable(ArrayList<Finding> list){
        System.out.println("=============showNoGroupingTreeTable==================");

        TSMutableTreeNode root = new TSMutableTreeNode("root");
        for(int index = 0; index < list.size(); index ++){
            DefaultMutableTreeNode node = new DefaultMutableTreeNode(list.get(index));
            root.add(node);
        }

        ListTreeTableModelOnColumns model = new ListTreeTableModelOnColumns(root, column);
        this.tree.setModel(model);
        this.tree.setRootVisible(false);

        this.tree.getSelectionModel().addListSelectionListener(listSelectionListener);
    }

    private void singleClickOnNode(Object node){

        System.out.println("=============singleClickOnNode==================");

        if(node instanceof ArrayList){
            ArrayList<Finding> findings = (ArrayList<Finding>)node;
            Severity severity = CommonUtils.getTypeSeverity(findings.get(0).getType());

            clearSeverityNum();

            switch (severity){
                case Blocker:
                    blockerValue.setText(findings.size() + "");
                    break;
                case Critical:
                    minorValue.setText(findings.size() + "");
                    break;
                case Major:
                    majorValue.setText(findings.size() + "");
                    break;
                case Minor:
                    minorValue.setText(findings.size() + "");
                    break;
                case Info:
                    infoValue.setText(findings.size() + "");
                    break;
                default:
            }

            totalValue.setText(findings.size() + "");

            this.rightPanel.setVisible(true);
            this.right1.setVisible(true);
            this.right2.setVisible(false);
            this.mainPanel.revalidate();
        }else{
            showAlert("Oooops, the node is broken");
        }
    }

    private void clearSeverityNum(){

        blockerValue.setText("0");
        criticalValue.setText("0");
        majorValue.setText("0");
        minorValue.setText("0");
        infoValue.setText("0");
        totalValue.setText("0");

    }

    private void singleClickOnLeaf(Object node){

//        System.out.println("=============singleClickOnLeaf==================");
//        if(node instanceof Finding) {
//            Finding finding = (Finding) node;
//            String html = "";

//            this.typeDescription.setText(html + DataUtils.getTypeName(finding.getType()));
//            this.msgValue.setText(html + finding.getInfo().getMessage().getValue());
//            this.sourceFile.setText(html + finding.getLocations().get(0).getFileName());
//            this.severity.setText(DataUtils.getTypeSeverity(finding.getType()).toString());
//            this.severity.setIcon(addIcon(finding));
//            this.category.setText(DataUtils.getTypeCategory(finding.getType()).toString());
//            this.type.setText(html + finding.getType().toString());
//
//            // add locations:
//            this.locations.removeAll();
//            ArrayList<TSLocation> locations = finding.getLocations();
//            if((locations == null) || (locations.size() == 0)){
//                showAlert("Oooops, the leaf node has no location information");
//                return;
//            }
//
//            for (int i = 0; i < locations.size(); i++){
//                if(locations.get(i) instanceof TSClass){
//                    break;
//                }
//                String line = locations.get(i).getLine();
//                if (line == null){
//                    showAlert("Oooops, no line number.");
//                }
//                String label = locations.get(i).getLabel();
//                String labelString = "";
//                if((label == null) || (label.toString().equals("catch"))){
//                    labelString = "Problem location";
//                }else if (label.toString().equals("guard_field")){
//                    continue;
//
//                }else{
//                    labelString = DataUtils.getLabelString(label);
//                }
//
//                JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
//                JLabel lineLabel = new JLabel(line);
//                JLabel description = new JLabel(labelString);
//
//                p.add(lineLabel);
//                p.add(description);
//
//                this.locations.setLayout(new GridLayout(0,1));
//                this.locations.add(p);
//            }
//
//            this.rightPanel.setVisible(true);
//            this.right1.setVisible(false);
//            this.right2.setVisible(true);
//            this.mainPanel.revalidate();
//        }else{
//            showAlert("Oooops, the leaf node is broken");
//            return;
//        }
    }

    private void showAlert(String alert){
        System.out.println(alert);
    }
}
