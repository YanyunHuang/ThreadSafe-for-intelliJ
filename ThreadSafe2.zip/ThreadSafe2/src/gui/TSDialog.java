package gui;

import com.intellij.openapi.ui.DialogWrapper;
import manager.PluginManager;
import manager.TSEngineManager;
import threadsafe.ThreadSafeCallable;
import util.DebugController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TSDialog extends JDialog {

    private static String WINDOW_ID = "ThreadSafe";

    private JPanel contentPane;
    private JButton buttonDetail;
    private JButton buttonBackground;
    private JProgressBar progressBar;
    private JCheckBox checkBox;
    private JButton buttonCancel;
    private JLabel licenseMsg;
    private JLabel moduleName;

    private ThreadDelegate threadDelegate;
    private DialogDelegate dialogDelegate;
    private boolean isShowInBackground = false;

    public TSDialog() {

        setContentPane(contentPane);
        setTitle(WINDOW_ID);
        setModal(true);
        getRootPane().setDefaultButton(buttonBackground);

        checkBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tickBackground();
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        buttonDetail.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onDetail();
            }
        });

        buttonBackground.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onBackground();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void tickBackground() {
        if(isShowInBackground){
            isShowInBackground = false;
            dialogDelegate.showInFront();
        }else{
            isShowInBackground = true;
            dialogDelegate.showInBackground();
        }
    }

    private void onDetail() {
        //TODO
    }

    private void onCancel() {
        // add your code here if necessary
        dialogDelegate.onCanceled();
        dispose();
    }

    private void onBackground() {
        // add your code here if necessary
        isShowInBackground = true;
        dialogDelegate.showInBackground();
        dispose();
    }


    public static void main(String[] args) {
        TSDialog dialog = new TSDialog();
        dialog.setDialogDelegate(PluginManager.getInstance());
        dialog.setThreadDelegate(PluginManager.getInstance());
        PluginManager.getInstance().setDialog(dialog);

//        dialog.setLocationRelativeTo(null);
        dialog.setSize(500, 169);
        final Toolkit toolkit = Toolkit.getDefaultToolkit();
        final Dimension screenSize = toolkit.getScreenSize();
        final int x = (screenSize.width - dialog.getWidth()) / 2;
        final int y = (screenSize.height - dialog.getHeight()) / 2;
        dialog.setLocation(x, y);

        dialog.pack();
        dialog.setVisible(true);

    }

    public ThreadDelegate getThreadDelegate() {
        return threadDelegate;
    }

    public void setThreadDelegate(ThreadDelegate threadDelegate) {
        this.threadDelegate = threadDelegate;
    }

    public DialogDelegate getDialogDelegate() {
        return dialogDelegate;
    }

    public void setDialogDelegate(DialogDelegate dialogDelegate) {
        this.dialogDelegate = dialogDelegate;
    }
}
