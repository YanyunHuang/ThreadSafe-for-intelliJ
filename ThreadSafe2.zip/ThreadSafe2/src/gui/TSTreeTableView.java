package gui;

import com.intellij.openapi.util.IconLoader;
import com.intellij.ui.ColoredTreeCellRenderer;
import com.intellij.ui.dualView.TreeTableView;
import com.intellij.ui.treeStructure.treetable.ListTreeTableModelOnColumns;
import model.ui.enums.TreeItemType;
import model.xml.Finding;
import org.jetbrains.annotations.NotNull;
import util.CommonUtils;
import util.DebugController;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

/**
 * Created by huangyanyun on 6/10/17.
 */
public class TSTreeTableView extends TreeTableView {

    public TSTreeTableView(ListTreeTableModelOnColumns treeTableModel) {
        super(treeTableModel);

        setTreeCellRenderer(new Renderer());
        DebugController.debug("============TSTreeTableView============");
        setRootVisible(false);
    }

    class Renderer extends ColoredTreeCellRenderer {

        @Override
        public void customizeCellRenderer(@NotNull JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {

//            DebugController.debug("============customizeCellRenderer============");

            DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;

            String description = "";
            if (node.getUserObject() instanceof TreeNodeData) {
                setIcon(createIcon((TreeNodeData) node.getUserObject()));
                description = ((TreeNodeData) node.getUserObject()).getName();
                int number = ((TreeNodeData) node.getUserObject()).getNumber();
                if(!leaf){
                    description = description + " (" + number + ")";
                }
            } else if (node.getUserObject() instanceof String) {
                description = (String) node.getUserObject();
            }
//            DebugController.debug("==description=" + description);
            append(description);
        }

        private Icon createIcon(TreeNodeData node){
            String path = "";
            if(node.getItemType() == TreeItemType.Severity){
                if(node.getContent() instanceof Finding){
                    path = CommonUtils.createSeverityIcon(((Finding)node.getContent()).getType());
                }else if(node.getContent() instanceof ArrayList){
                    path = CommonUtils.createSeverityIcon(((Finding)((ArrayList) node.getContent()).get(0)).getType());
                }
            }else{
                path = CommonUtils.createProjectIcon(node.getItemType());
            }
            if(IconLoader.findIcon(path) != null){
                return IconLoader.findIcon(path);
            }else{
                return null;
            }

        }
    }

}
