package marker;

import com.intellij.psi.PsiElement;

/**
 * Created by huangyanyun on 7/16/17.
 */
public class ProblemDescription {
    private boolean isProblemLocation;
    private PsiElement textRange;
    private String label;
    private int line;

    public ProblemDescription(boolean isProblemLocation, PsiElement textRange, String label, int line){
        this.isProblemLocation = isProblemLocation;
        this.textRange = textRange;
        this.label = label;
        this.setLine(line);
    }

    public boolean isProblemLocation() {
        return isProblemLocation;
    }

    public void setProblemLocation(boolean problemLocation) {
        isProblemLocation = problemLocation;
    }

    public PsiElement getTextRange() {
        return textRange;
    }

    public void setTextRange(PsiElement textRange) {
        this.textRange = textRange;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }
}
