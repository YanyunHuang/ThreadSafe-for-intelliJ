package marker;

import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.impl.FileDocumentManagerImpl;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.popup.PopupStep;
import com.intellij.openapi.ui.popup.util.BaseListPopupStep;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.util.Iconable;
import com.intellij.openapi.vfs.ReadonlyStatusHandler;
import com.intellij.psi.PsiElement;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Created by huangyanyun on 7/16/17.
 */
public class RootGroupBugIntentionListPopupStep extends BaseListPopupStep<String> implements Iconable {

    private final PsiElement _psiElement;
    private ArrayList<ProblemDescription> _descriptions;
    private String lineNum;

    public RootGroupBugIntentionListPopupStep(PsiElement _psiElement, ArrayList<ProblemDescription> descriptions, String lineNum){

        super(null,
                "Go to Issue Marker");
        this._psiElement = _psiElement;
        this._descriptions = descriptions;
        this.lineNum = lineNum;
    }

    @Override
    public Icon getIcon(int flags) {
        return IconLoader.findIcon("/icons/intelli/back.png");
    }

    @Override
    public PopupStep onChosen(String selectedValue, final boolean finalChoice) {

        int line = Integer.parseInt(lineNum);

        final Project project = _psiElement.getProject();
        ReadonlyStatusHandler.getInstance(project).ensureFilesWritable();


        new WriteCommandAction.Simple/*<Object>*/(project, "Add ThreadSafe-idea Suppress warning", _psiElement.getContainingFile()) {

            @Override
            protected void run() throws Throwable {
                final Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
                FileDocumentManagerImpl impl = (FileDocumentManagerImpl) FileDocumentManager.getInstance();
                Document document = impl.getDocument(_psiElement.getContainingFile().getVirtualFile());
                int startOffset = document.getLineStartOffset(line -1);
                int endOffset = document.getLineEndOffset(line -1);
                editor.getSelectionModel().setSelection(startOffset, endOffset);
            }
        }.execute();

        return super.onChosen(selectedValue, finalChoice);
    }
}
