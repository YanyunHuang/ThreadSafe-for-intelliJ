package marker;

import com.intellij.codeInsight.daemon.GutterIconNavigationHandler;
import com.intellij.codeInsight.daemon.LineMarkerInfo;
import com.intellij.codeInsight.daemon.LineMarkerProvider;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.editor.markup.GutterIconRenderer;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.ui.popup.JBPopup;
import com.intellij.openapi.ui.popup.JBPopupFactory;
import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.*;
import com.intellij.psi.impl.source.PsiJavaFileImpl;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.ui.awt.RelativePoint;
import intellij.Tools;
import manager.PluginManager;
import model.xml.Field;
import model.xml.Finding;
import model.xml.TSLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import util.CommonUtils;
import util.ExtendedProblemDescriptor;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.util.*;
import com.intellij.util.Function;
import java.util.regex.Pattern;

/**
 * Created by huangyanyun on 7/9/17.
 */


public class TSLineMarkerProvider implements LineMarkerProvider {

    private Icon icon = IconLoader.findIcon("/icons/obj16/location.gif");
    public TSLineMarkerProvider() {
    }

    /**
     * TODO: Note that this method could be invoked outside EDT!
     */
    @Override
    @Nullable
    public LineMarkerInfo<?> getLineMarkerInfo(@NotNull final PsiElement psiElement) {

        final PsiFile psiFile = psiElement.getContainingFile();
        final LinkedHashMap<Module, ArrayList<Finding>> findingData =
                PluginManager.getInstance().getFindingData();

        ArrayList<Finding> findings = getFindingFromFile(findingData, psiFile.getVirtualFile());
        if(findings.size() < 1){
            return null;
        }

        ArrayList<ProblemDescription> matchingDescriptors = new ArrayList<ProblemDescription>();
        Finding targetFinding = null;
        for(Finding finding : findings){
            ArrayList<TSLocation> location = finding.getLocations();
            if(location.size() == 0){
                continue;
            }
            for(TSLocation lo: location){
                int line = Integer.parseInt(lo.getLine()) - 1;
                final PsiElement problemPsiElement = ExtendedProblemDescriptor.getElementAtLine(
                        psiFile, line);

                if (psiElement.equals(problemPsiElement)) {
                    targetFinding = finding;
                    ProblemDescription problemDescription = new ProblemDescription(lo.isProblemLocation(),
                            problemPsiElement, lo.getLabel(), Integer.parseInt(lo.getLine()));
                    matchingDescriptors.add(problemDescription);
                }
            }
        }
        if(!matchingDescriptors.isEmpty()){
            final GutterIconNavigationHandler<PsiElement> navHandler =
                    new TSGutterIconNavigationHandler(psiElement, matchingDescriptors,
                            matchingDescriptors.get(0).getLine()+"");
            return new LineMarkerInfo<PsiElement>(psiElement,
                    psiElement.getTextRange().getStartOffset(),
                    getIcon(targetFinding, matchingDescriptors),
                    4,
                    new TooltipProvider(targetFinding, matchingDescriptors),
                    navHandler,
                    GutterIconRenderer.Alignment.LEFT);
        }
        return null;
    }

    @NotNull
    public static Icon getIcon(Finding finding, ArrayList<ProblemDescription> problemDescriptions) {

        for(ProblemDescription problemDescription : problemDescriptions){

            if(!problemDescription.isProblemLocation()){
                return IconLoader.findIcon("/icons/obj16/location.gif");
            }else{
                switch(CommonUtils.getTypeSeverity(finding.getType())) {
                    case Blocker:
                        return IconLoader.findIcon("/icons/obj16/blocker.png");
                    case Critical:
                        return IconLoader.findIcon("/icons/obj16/critical.png");
                    case Major:
                        return IconLoader.findIcon("/icons/obj16/major.png");
                    case Minor:
                        return IconLoader.findIcon("/icons/obj16/minor.png");
                    case Info:
                        return IconLoader.findIcon("/icons/obj16/info.png");
                }
            }
        }
        return IconLoader.findIcon("/icons/obj16/location.gif");
    }

    /**
     * @param findingData all findings
     * @param virtualFile current file
     * @return
     */
    private ArrayList<Finding> getFindingFromFile(LinkedHashMap<Module, ArrayList<Finding>> findingData, VirtualFile virtualFile) {

        ArrayList<Finding> results = new ArrayList<Finding>();
        Iterator it = findingData.entrySet().iterator();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            ArrayList<Finding> findings = (ArrayList<Finding>) pair.getValue();
            if((findings != null) && (findings.size() > 0)){
                for(Finding finding: findings){
                    String path = finding.getLocations().get(0).getPath();
                    VirtualFile vf = PluginManager.getInstance().getCurrentPro().getBaseDir().getParent().findFileByRelativePath(path);
//                    GlobalSearchScope scope = GlobalSearchScope.allScope (PluginManager.getInstance().getCurrentPro());
//                    PsiClass targetClass = JavaPsiFacade.getInstance(PluginManager.getInstance().getCurrentPro()).
//                            findClass(className, scope);

//                    VirtualFile vf = targetClass.getContainingFile().getVirtualFile();
                    if (vf.equals(virtualFile)){
                        results.add(finding);
                    }
                }
            }
        }
        return results;
    }

    public void collectSlowLineMarkers(@NotNull final List<PsiElement> elements, @NotNull final Collection<LineMarkerInfo> result) {
    }

    private static class TSGutterIconNavigationHandler implements GutterIconNavigationHandler<PsiElement> {

        private final ArrayList<ProblemDescription> _descriptors;
        private final PsiElement _psiElement;
        private final String _lineNum;

        private TSGutterIconNavigationHandler(final PsiElement psiElement, final ArrayList<ProblemDescription> descriptors, String lineNum) {
            _descriptors = descriptors;
            _psiElement = psiElement;
            this._lineNum = lineNum;
            //buildPopupMenu();
        }

        @Override
        public void navigate(final MouseEvent e, final PsiElement psiElement) {
            for(ProblemDescription problemDescription : _descriptors){
                if((problemDescription.isProblemLocation()) && (problemDescription.getTextRange().equals(psiElement))){
                    return;
                }
            }
            buildPopupMenu().show(new RelativePoint(e));
        }

        @SuppressWarnings({"AnonymousInnerClass", "AnonymousInnerClassMayBeStatic"})
        private JBPopup buildPopupMenu() {
            final JBPopupFactory factory = JBPopupFactory.getInstance();
            return factory.createListPopup(new RootGroupBugIntentionListPopupStep(_psiElement, _descriptors, _lineNum));
        }
    }

    private static class TooltipProvider implements Function<PsiElement, String> {

        private final ArrayList<ProblemDescription> _problemDescriptors;
        private final Finding finding;
        @SuppressWarnings("HardcodedLineSeparator")
        private static final Pattern PATTERN = Pattern.compile("\n");


        private TooltipProvider(final Finding finding, final ArrayList<ProblemDescription> problemDescriptors) {
            this.finding = finding;
            _problemDescriptors = problemDescriptors;
        }


        public String fun(final PsiElement psiElement) {
            return getTooltipText(finding, _problemDescriptors);
        }

        @SuppressWarnings({"HardcodedFileSeparator"})
        private static String getTooltipText(final Finding finding, final ArrayList<ProblemDescription> problemDescriptors) {
            final StringBuilder buffer = new StringBuilder();
            for(ProblemDescription problemDescription : problemDescriptors){
                if(problemDescription.isProblemLocation()){
                    buffer.append(finding.getInfo().getMessage().getValue());
                }else{
                    buffer.append(CommonUtils.getTypeName(finding.getType()));
                    buffer.append(": ");
                    buffer.append(CommonUtils.getLabelString(problemDescription.getLabel()));
                }
            }
            return buffer.toString();
        }


        @Override
        public String toString() {
            return "TooltipProvider" + "{_problemDescriptor=" + _problemDescriptors + '}';
        }
    }

}
