package model.xml;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class Instruction extends TSLocation {

    private String method;
    private String offset;
    private String desc;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getOffset() {
        return offset;
    }

    public void setOffset(String offset) {
        this.offset = offset;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
