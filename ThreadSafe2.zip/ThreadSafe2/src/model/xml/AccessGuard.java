package model.xml;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class AccessGuard {

    private GuardRef guardRef;

    public GuardRef getGuardRef() {
        return guardRef;
    }

    public void setGuardRef(GuardRef guardRef) {
        this.guardRef = guardRef;
    }
}
