package model.xml.enums;

/**
 * Created by huangyanyun on 5/31/17.
 */
public enum MethodType {

    lockedGet,
    lockedPut,
    getValue,
    run,
    increment,
    decrement,
    get,
    add,
    remove,
    getOrCreate,
    available,
    take,
    setLock,
    replace,
    init,
    test,
    test1,
    test2,
    method1,
    method2,
    synchronizeOnStringOrInteger,
    synchronizeOnStringLiteral,
    synchronizeOnBoolean,
    ensurePresent,
    putIfMissing,
    iterateSubList,
    getAndIncrementBad,
    update,
    addValue

}
