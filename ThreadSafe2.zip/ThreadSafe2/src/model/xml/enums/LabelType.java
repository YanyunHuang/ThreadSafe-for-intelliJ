package model.xml.enums;

/**
 * Created by huangyanyun on 5/31/17.
 * unused
 */
public enum LabelType {

    relevant_sync_read,
    relevant_sync_write,
    guard_field,
    guard_type,
    relevant_unsync_read,
    async_entrypoint,
    relevant_unsync_write,
    blockingremove,
    insert,
    replaced_field,
    safe_assignment,
    unsafe_assignment,
    irrelevant_unsync_write,
    put,
    get,
    check,
    creation,
    collection_lock,
    view_lock,
    lock,
    is_locked,
    mutation,
    leaked_via


}
