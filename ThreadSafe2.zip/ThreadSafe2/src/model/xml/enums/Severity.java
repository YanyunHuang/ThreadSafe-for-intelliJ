package model.xml.enums;

/**
 * Created by huangyanyun on 6/7/17.
 */
public enum Severity {
    Blocker,
    Critical,
    Major,
    Minor,
    Info
}
