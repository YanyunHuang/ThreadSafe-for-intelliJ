package model.xml.enums;

/**
 * Created by huangyanyun on 6/7/17.
 */
public enum Category {
    Collections,
    Locking,
    Bad_practice,
    Immutability
}
