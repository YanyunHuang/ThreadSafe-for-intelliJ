package model.xml;

import model.xml.enums.FindingType;

import java.util.ArrayList;

/**
 * Created by huangyanyun on 5/31/17.
 * root class in findings.xml
 */
public class Finding {

    private FindingType type;
    private ArrayList<TSLocation> locations;
    private TSInfo info;

    public FindingType getType() {
        return type;
    }

    public void setType(FindingType type) {
        this.type = type;
    }

    public TSInfo getInfo() {
        return info;
    }

    public void setInfo(TSInfo info) {
        this.info = info;
    }

    public ArrayList<TSLocation> getLocations() {
        return locations;
    }

    public void setLocations(ArrayList<TSLocation> locations) {
        this.locations = locations;
    }
}
