package model.xml;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class Message {

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
