package model.xml;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class LocationRef {

    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
