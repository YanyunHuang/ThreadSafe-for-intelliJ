package model.xml;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class Access {

    private String location;
    private String type;
    private AccessGuard accessGuard;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public AccessGuard getAccessGuard() {
        return accessGuard;
    }

    public void setAccessGuards(AccessGuard accessGuard) {
        this.accessGuard = accessGuard;
    }
}
