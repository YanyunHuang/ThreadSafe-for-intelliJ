package model.xml;

import java.util.ArrayList;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class TSInfo {

    private Message message;
    private ArrayList<GuardRelative> guards;
    private ArrayList<Access> accesses;


    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public ArrayList<GuardRelative> getGuards() {
        return guards;
    }

    public void setGuards(ArrayList<GuardRelative> guards) {
        this.guards = guards;
    }

    public ArrayList<Access> getAccesses() {
        return accesses;
    }

    public void setAccesses(ArrayList<Access> accesses) {
        this.accesses = accesses;
    }
}
