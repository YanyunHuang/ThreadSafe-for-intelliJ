package model.xml;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class GuardRef {

    private String key;
    private String status;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
