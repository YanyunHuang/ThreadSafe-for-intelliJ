package model.xml;

import com.intellij.openapi.module.Module;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class TSLocation {
    private String key;
    private String label;
    private String fileName;
    private String className;
    private String line;
    private String path;
    private Module moduleName;
    private boolean isProblemLocation = false;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Module getModuleName() {
        return moduleName;
    }

    public void setModuleName(Module moduleName) {
        this.moduleName = moduleName;
    }

    public boolean isProblemLocation() {
        return isProblemLocation;
    }

    public void setProblemLocation(boolean problemLocation) {
        isProblemLocation = problemLocation;
    }
}
