package model.xml;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class GuardRelative {

    private String typeRef;
    private String key;
    private String intrinsic;
    //nullable
    private GuardPath guardPath;
    private TargetPath targetPath;


    public String getTypeRef() {
        return typeRef;
    }

    public void setTypeRef(String typeRef) {
        this.typeRef = typeRef;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getIntrinsic() {
        return intrinsic;
    }

    public void setIntrinsic(String intrinsic) {
        this.intrinsic = intrinsic;
    }

    public GuardPath getGuardPath() {
        return guardPath;
    }

    public void setGuardPath(GuardPath guardPath) {
        this.guardPath = guardPath;
    }

    public TargetPath getTargetPath() {
        return targetPath;
    }

    public void setTargetPath(TargetPath targetPath) {
        this.targetPath = targetPath;
    }
}
