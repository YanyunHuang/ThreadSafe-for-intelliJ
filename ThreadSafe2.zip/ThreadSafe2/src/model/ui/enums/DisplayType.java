package model.ui.enums;

/**
 * Created by huangyanyun on 6/16/17.
 */
public enum DisplayType {

    Selected,
    All
}
