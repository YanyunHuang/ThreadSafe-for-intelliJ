package model.ui.enums;

/**
 * Created by huangyanyun on 7/2/17.
 */
public enum TreeItemType {

    Severity,
    Project,
    Folder,
    Package,
    File
}
