package model.ui.enums;

/**
 * Created by huangyanyun on 6/8/17.
 */
public enum GroupType {

    Type,
    Severity,
    Resource,
    Project,
    No_grouping
}
