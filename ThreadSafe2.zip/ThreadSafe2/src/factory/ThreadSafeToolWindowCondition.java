package factory;
import com.intellij.openapi.util.Condition;

/**
 * Created by huangyanyun on 6/19/17.
 */
public class ThreadSafeToolWindowCondition implements Condition {
    @Override
    public boolean value(Object o) {

        return true;
    }
}
