package factory;

import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowFactory;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import gui.TSDefaultActionGroup;
import gui.TSToolWindow;
import manager.PluginManager;
import model.xml.Finding;
import org.jetbrains.annotations.NotNull;
import util.DebugController;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Created by huangyanyun on 5/31/17.
 */
public class ThreadSafeToolWindowFactory implements ToolWindowFactory {

    public void createToolWindowContent(@NotNull Project project, @NotNull ToolWindow toolWindow){

        //get xml
        DebugController.debug("createToolWindowContent=====");
        PluginManager controller = PluginManager.getInstance();
        controller.setCurrentPro(project);
        controller.readFiles();

        TSToolWindow tsToolWindow = TSToolWindow.getInstance();
        controller.displayTree();
//        tsToolWindow.updateTree(project, findings, GroupType.No_grouping, controller.getDisplayType());

        ContentFactory contentFactory = ContentFactory.SERVICE.getInstance();
        JPanel mainPanel = tsToolWindow.getMainPanel();
        Content content = contentFactory.createContent(mainPanel, "", false);

        DefaultActionGroup actionGroup = TSDefaultActionGroup.getInstance();
        ActionToolbar toolBar = ActionManager.getInstance()
                .createActionToolbar("Toolbar", actionGroup, false);
        mainPanel.add(toolBar.getComponent(), BorderLayout.WEST);

        toolWindow.getContentManager().addContent(content);
//        updateTree(project, findings, GroupType.No_grouping, controller.getDisplayType());
    }

//    private static void updateTree(Project project, ArrayList<Finding> list, GroupType group, DisplayType dis){
//        ViewController controller = ViewController.getInstance();
//        controller.changeSort(GroupType.No_grouping);
//        controller.getToolWindow().updateTreeTable(project, list, group, dis);
//    }
}
