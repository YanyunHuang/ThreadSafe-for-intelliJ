package manager;

import com.intellij.ide.DataManager;
import com.intellij.ide.projectView.impl.AbstractProjectViewPane;
import com.intellij.ide.projectView.impl.ProjectViewImpl;
import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.fileEditor.OpenFileDescriptor;
import com.intellij.openapi.fileEditor.impl.FileDocumentManagerImpl;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiManager;
import com.intellij.psi.impl.file.PsiJavaDirectoryImpl;
import com.intellij.psi.search.GlobalSearchScope;
import gui.TSToolWindow;
import help.TSHelpSet;
import intellij.Tools;
import model.ui.enums.DisplayType;
import model.ui.enums.GroupType;
import model.xml.Field;
import model.xml.Finding;
import model.xml.TSLocation;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * Created by huangyanyun on 7/15/17.
 */
public class ViewManager {

    private static ViewManager instance;
    private boolean LISTEN_TO_PROJECT = false;
    private static final GroupType DEFAULT_GROUP_TYPE = GroupType.Type;
    private static final DisplayType DEFAULT_DISPLAY_TYPE = DisplayType.All;

    private DisplayType displayType = DEFAULT_DISPLAY_TYPE;
    private GroupType groupType = DEFAULT_GROUP_TYPE;

    public static ViewManager getInstance(){
        if (instance == null){
            instance = new ViewManager();
        }
        return instance;
    }

    TreeSelectionListener projectListener = new TreeSelectionListener() {
        @Override
        public void valueChanged(TreeSelectionEvent e) {
            displayTree();
        }
    };

    public void setDisplayType(DisplayType displayType) {
        this.displayType = displayType;
        LISTEN_TO_PROJECT = (this.displayType == DisplayType.All)? false: true;
        if(LISTEN_TO_PROJECT){
            addProjectListener();
        }else{
            removeProjectListener();
        }
    }

    private void addProjectListener() {
        ProjectViewImpl impl = (ProjectViewImpl) ProjectViewImpl.getInstance(PluginManager.getInstance().getCurrentPro());
        impl.getCurrentProjectViewPane().getTree().getSelectionModel().addTreeSelectionListener(projectListener);
    }

    private void removeProjectListener() {
        ProjectViewImpl impl = (ProjectViewImpl) ProjectViewImpl.getInstance(PluginManager.getInstance().getCurrentPro());
        impl.getCurrentProjectViewPane().getTree().getSelectionModel().removeTreeSelectionListener(projectListener);
    }

    public void displayTree(){

        PluginManager manager = PluginManager.getInstance();
        LinkedHashMap<Module, ArrayList<Finding>> displayList = filterListByDisplayType(manager.getFindingData());

        if(groupType == GroupType.Project){
            //TODO
            TSToolWindow.getInstance().updateTree(manager.getCurrentPro(), displayList, groupType, displayType);
        }else{
            ArrayList<Finding> targetList = converToList(displayList);
            TSToolWindow.getInstance().updateTree(manager.getCurrentPro(), targetList, groupType, displayType);
        }
    }

    private ArrayList<Finding> converToList(LinkedHashMap<Module, ArrayList<Finding>> source){
        ArrayList<Finding> result = new ArrayList<Finding>();
        if(source.size() > 0){
            Iterator it = source.entrySet().iterator();
            while (it.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry) it.next();
                ArrayList<Finding> value = (ArrayList<Finding>) pair.getValue();
                if(value != null){
                    result.addAll(value);
                }
            }
        }
        return result;
    }

    public void changeSort(GroupType type) {
        this.groupType = type;
        displayTree();
    }

    private LinkedHashMap<Module, ArrayList<Finding>> filterListByDisplayType(LinkedHashMap<Module, ArrayList<Finding>> original) {
        if(displayType.equals(DisplayType.All)){
            return original;
        }else{

            LinkedHashMap<Module, ArrayList<Finding>> results = new LinkedHashMap<Module, ArrayList<Finding>>();
            ArrayList<VirtualFile> selectedFiles = getSelectedFileFromProjectView();

            Iterator it = original.entrySet().iterator();
            while (it.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry) it.next();
                ArrayList<Finding> findings = (ArrayList<Finding>) pair.getValue();
                if((findings == null) || (findings.size() == 0)){
                    continue;
                }

                ArrayList<Finding> module = new ArrayList<Finding>();
                for(Finding finding : findings){
                    String classFile = finding.getLocations().get(0).getPath();
                    VirtualFile vf = PluginManager.getInstance().getCurrentPro().
                            getBaseDir().getParent().findFileByRelativePath(classFile);
                    if(vf != null){
                        if(selectedFiles.contains(vf)){
                            module.add(finding);
                        }
                    }
                }
                if(module.size() > 0){
                    results.put((Module) pair.getKey(), module);
                }
            }
            return results;
        }
    }

    private ArrayList<VirtualFile> getSelectedFileFromProjectView() {

        ArrayList<VirtualFile> selectedPath = getPathsFromEvent();
        if((selectedPath != null) && (selectedPath.size() > 0)){
            return getChildrenFilesFromDirectory(selectedPath);
        }
        return null;
    }

    private ArrayList<VirtualFile> getPathsFromEvent() {

        ArrayList<VirtualFile> result = new ArrayList<VirtualFile>();
        ProjectViewImpl impl = (ProjectViewImpl) ProjectViewImpl.getInstance(
                PluginManager.getInstance().getCurrentPro());
        AbstractProjectViewPane viewPane = impl.getCurrentProjectViewPane();
        PsiElement[] selectedPath = viewPane.getSelectedPSIElements();
        for(PsiElement element : selectedPath){
            if(element instanceof PsiClass){
                VirtualFile file = element.getContainingFile().getViewProvider().getVirtualFile();
                result.add(file);
            }else if(element instanceof PsiJavaDirectoryImpl){
                VirtualFile file = ((PsiJavaDirectoryImpl) element).getVirtualFile();
                result.add(file);
            }else{

            }
        }
        return result;
    }

    private ArrayList<VirtualFile> getChildrenFilesFromDirectory(ArrayList<VirtualFile> selectedPath){

        ArrayList<VirtualFile> targetFiles = new ArrayList<VirtualFile>();
        for (VirtualFile path: selectedPath){
            if(path.isDirectory()){
                VirtualFile[] children = path.getChildren();

                ArrayList<VirtualFile> direc = getChildrenFilesFromDirectory(createList(children));
                targetFiles.addAll(direc);
            }else{
                targetFiles.add(path);
            }
        }
        return targetFiles;
    }

    private ArrayList<VirtualFile> createList(VirtualFile[] files){
        ArrayList<VirtualFile> result = new ArrayList<VirtualFile>();
        for(VirtualFile file: files){
            result.add(file);
        }
        return result;

    }

    public void changeDisplayType(DisplayType all) {
        setDisplayType(all);
        displayTree();
    }

    public void clear() {
        displayTree();
        TSToolWindow.getInstance().clear();
    }

    public void collapse() {
        TSToolWindow.getInstance().collapse();
    }

    public void expand() {
        TSToolWindow.getInstance().expand();
    }

    /**
     * open the editor and redirect
     * @param location VirtualFile to display
     * @param lineNum Specific line to focus
     */
    public void openEditorToolWindow(TSLocation location, String lineNum) {

        PluginManager manager = PluginManager.getInstance();
        Project currentPro = manager.getCurrentPro();
        FileEditorManager fileEditorManager = FileEditorManager.getInstance(currentPro);

        GlobalSearchScope scope = GlobalSearchScope.allScope (PluginManager.getInstance().getCurrentPro());

        VirtualFile vf = currentPro.getBaseDir().getParent().findFileByRelativePath(location.getPath());
        if(vf == null){
            Messages message = new Messages();
            String options[] = {"OK", "Cancel"};
            message.showDialog(currentPro, location.getPath() +" file not exist.", "Warning",null, options, 0, 0, null);
        }

        FileDocumentManagerImpl impl = (FileDocumentManagerImpl) FileDocumentManager.getInstance();
        Document document = impl.getDocument(vf);

        int line = Integer.parseInt(lineNum);
        if(line < 1){
            line = Tools.getFieldLineNumber(document, PsiManager.getInstance(currentPro).findFile(vf), ((Field)location).getName());
            line += 1;
            location.setLine(line + "");
        }
        int startOffset = document.getLineStartOffset(line - 1);
        int endOffset = document.getLineEndOffset(line - 1);

        OpenFileDescriptor descriptor = new OpenFileDescriptor(currentPro, vf,
                Integer.parseInt(lineNum) -1, endOffset - startOffset);
        fileEditorManager.openTextEditor(descriptor, true);

        Editor editor = fileEditorManager.getSelectedTextEditor();
        editor.getSelectionModel().setSelection(startOffset, endOffset);
    }

    /**
     * invoke call hierarchy function
     * @param e
     * @param finding
     */
    public void callHierarchy(MouseEvent e, Finding finding) {

        PluginManager plugin = PluginManager.getInstance();
        Project currentPro = plugin.getCurrentPro();
        openEditorToolWindow(finding.getLocations().get(0),
                finding.getLocations().get(0).getLine());

        ActionManager manager = ActionManager.getInstance();
        AnAction callHierarchy = manager.getAction(IdeActions.ACTION_TYPE_HIERARCHY);
        DataContext dataContext = DataManager.getInstance().getDataContext(
                FileEditorManager.getInstance(currentPro).getSelectedTextEditor().getContentComponent());
        callHierarchy.actionPerformed(AnActionEvent.createFromAnAction(
                callHierarchy, null, ActionPlaces.UNKNOWN, dataContext));

    }

    /**
     * display help content
     * @param finding specific finding type to display
     */
    public void openUrl(Finding finding) {
        TSHelpSet hs = TSHelpSet.getInstance();
        hs.showHelp(finding.getType().toString());
    }

}
