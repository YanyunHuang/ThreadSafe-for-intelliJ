package manager;

import com.intellij.openapi.actionSystem.ActionManager;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.Separator;
import com.intellij.openapi.components.ApplicationComponent;
import gui.TSDefaultActionGroup;
import org.jetbrains.annotations.NotNull;

/**
 * Created by huangyanyun on 6/16/17.
 */
public class UIManager implements ApplicationComponent {

    @NotNull
    @Override
    public String getComponentName() {
        return getClass().getSimpleName();
    }

    @Override
    public void disposeComponent() { }

    @Override
    public void initComponent() {

        ActionManager manager = ActionManager.getInstance();
        TSDefaultActionGroup all = TSDefaultActionGroup.getInstance();
        manager.registerAction("all", all);

        AnAction run = manager.getAction("runAction");
        all.add(run);
        AnAction clear = manager.getAction("clearAction");
        all.add(clear);
        all.add(new Separator());
        AnAction coll = manager.getAction("collapseAction");
        all.add(coll);
        AnAction expand = manager.getAction("expandAction");
        all.add(expand);
        all.add(new Separator());
        AnAction showAll = manager.getAction("ts.showall");
        all.add(showAll);
        AnAction selected = manager.getAction("ts.selected");
        all.add(selected);
        AnAction pro = manager.getAction("ts.project");
        all.add(pro);
        AnAction typed = manager.getAction("ts.typed");
        all.add(typed);
        AnAction severity = manager.getAction("ts.severity");
        all.add(severity);
        AnAction resource = manager.getAction("ts.resource");
        all.add(resource);
        AnAction no = manager.getAction("ts.nogroup");
        all.add(no);
    }
}
