package manager;

import com.intellij.openapi.module.Module;
import gui.*;
import threadsafe.TSThread;
import threadsafe.TSThreadMsg;
import threadsafe.ThreadSafeCallable;
import util.DebugController;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by huangyanyun on 7/3/17.
 */
public class TSEngineManager{

    private static TSEngineManager instance;
    private ThreadDelegate delegate;

    public static TSEngineManager getInstance() {
        if (instance == null) {
            instance = new TSEngineManager();
        }
        return instance;
    }

    public void setDelegate(ThreadDelegate delegate) {
        this.delegate = delegate;
    }

    public void analyse(ArrayList<Module> toAnalysesModules) {

        if((toAnalysesModules == null) || (toAnalysesModules.size() ==0)){
            return;
        }

        int index = 0;
        while(index < toAnalysesModules.size()){
            Thread thread = new Thread(new TSThread(toAnalysesModules.get(index), true, null));
            thread.start();
            try {
                thread.join();
                index ++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if(delegate != null){
            delegate.finish();
        }
//        PluginManager.getInstance().getInputQueue().add(new TSThreadMsg(true, 1, null));
    }
}
