package manager;

import com.intellij.CommonBundle;
import com.intellij.codeInsight.daemon.DaemonCodeAnalyzer;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.compiler.CompileContext;
import com.intellij.openapi.compiler.CompileStatusNotification;
import com.intellij.openapi.compiler.CompilerManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowManager;
import gui.DialogDelegate;
import gui.TSDialog;
import gui.ThreadDelegate;
import model.ui.enums.DisplayType;
import model.ui.enums.GroupType;
import model.xml.Finding;
import model.xml.TSLocation;
import threadsafe.TSThreadMsg;
import threadsafe.ThreadSafeCallable;
import util.DebugController;
import util.EventDispatchThreadHelper;
import util.FileManager;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * Created by huangyanyun on 6/16/17.
 */
public class PluginManager implements DialogDelegate, ThreadDelegate{

    private Project currentPro;
    private Module currentMod;
    private static PluginManager instance;
    private LinkedHashMap<Module, ArrayList<Finding>> findingData = new LinkedHashMap<Module, ArrayList<Finding>>();
    private ArrayList<Module> toAnalysesModules = new ArrayList<Module>();

    private static boolean showInBackground = false;
    private TSDialog dialog;
    private boolean isCanceled = false;
    private ArrayList<TSThreadMsg> inputQueue = new ArrayList<TSThreadMsg>();

    public static PluginManager getInstance(){
        if (instance == null){
            instance = new PluginManager();
        }
        return instance;
    }

    public Project getCurrentPro() {
        return currentPro;
    }

    public void setCurrentPro(Project currentPro) {
        this.currentPro = currentPro;
    }

    public LinkedHashMap<Module, ArrayList<Finding>> getFindingData() {
        return findingData;
    }

    public void readFiles(){
        Module[] modules = ModuleManager.getInstance(getCurrentPro()).getModules();
        if((modules != null) && (modules.length > 0)){
            for (Module module: modules){
                String findingLocation = module.getProject().getBasePath()+
                        "/threadsafe-results/" + module.getName() + "/findings.xml";
                File file = new File(findingLocation);
                if(file.exists()){
                    ArrayList<Finding> list = FileManager.parseFindings(module, findingLocation);
                    if(list == null){
                        list = new ArrayList<Finding>();
                    }
                    getFindingData().put(module, list);
                }
            }
        }
    }

    public void displayTree(){
        ViewManager.getInstance().displayTree();
    }

    public void changeSort(GroupType type) {
        ViewManager.getInstance().changeSort(type);
    }

    public void changeDisplayType(DisplayType all) {
        ViewManager.getInstance().changeDisplayType(all);
   }

    /**
     * analyses all modules that ran before
     * @param e
     */
    public void runAll(AnActionEvent e){

        isCanceled = false;
        Project project = e.getProject();
        if(!isValid()){
            Messages.showMessageDialog(currentPro, "Expired!", CommonBundle.getWarningTitle(),
                    Messages.getErrorIcon());
            return;
        }
        if(currentPro == null){
            currentPro = project;
            findingData.clear();
            return;
        }else if (!(currentPro.equals(project))){
            currentPro = project;
            findingData.clear();
            return;
        }else{
            Iterator it = findingData.entrySet().iterator();
            while (it.hasNext()) {
                HashMap.Entry pair = (HashMap.Entry) it.next();
                Module m = (Module) pair.getKey();
                addModule(m);
            }
            buildProject();
        }
    }

    /**
     * analyses all modules that in the project
     * @param e
     */
    public void runProject(AnActionEvent e){
        isCanceled = false;
        currentPro = e.getProject();
        if(!isValid()){
            Messages.showMessageDialog(currentPro, "Expired!", CommonBundle.getWarningTitle(),
                    Messages.getErrorIcon());
            return;
        }
        findingData.clear();

        Module[] modules = ModuleManager.getInstance(currentPro).getModules();
        if((modules != null) && (modules.length > 0)){
            for(Module module : modules){
                addModule(module);
            }
        }
        buildProject();
    }

    private boolean isValid() {
        return LicenceManager.isValid();
    }

    /**
     * mark module in waiting list
     * @param m
     */
    private void addModule(Module m){
        toAnalysesModules.add(m);
    }

    /**
     * compile project to generate classes
     */
    private void buildProject(){

        CompileStatusNotification myCallback = new CompileStatusNotification() {
            @Override
            public void finished(boolean aborted, int errors, int warnings, CompileContext compileContext) {
                if(aborted){
                    return;
                }else if(errors == 0){
                    runEngine();
                }else{
                    Messages.showMessageDialog(currentPro, "Build error!", CommonBundle.getErrorTitle(),
                            Messages.getErrorIcon());
                }
            }
        };
        CompilerManager.getInstance(currentPro).make(myCallback);
    }

    /**
     * command to start ThreadSafe engine
     */
    private void runEngine() {
        if(toAnalysesModules.size() == 0){
            return;
        }

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                if(!showInBackground){
                    showDialog();
                }
                TSEngineManager engine = TSEngineManager.getInstance();
                engine.setDelegate(PluginManager.getInstance());
                engine.analyse(toAnalysesModules);

            }
        });
        thread.start();
    }

    /**
     * show a dialog to display analysing msg
     */
    private void showDialog(){
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                TSDialog dialog = new TSDialog();
                setDialog(dialog);
                dialog.setDialogDelegate(PluginManager.getInstance());
                dialog.setThreadDelegate(PluginManager.getInstance());
                PluginManager.getInstance().setDialog(dialog);

                dialog.setSize(500, 169);
                final Toolkit toolkit = Toolkit.getDefaultToolkit();
                final Dimension screenSize = toolkit.getScreenSize();
                final int x = (screenSize.width - dialog.getWidth()) / 2;
                final int y = (screenSize.height - dialog.getHeight()) / 2;
                dialog.setLocation(x, y);

                dialog.pack();
                dialog.setVisible(true);
            }
        });
        thread.start();
    }

    /**
     * execute clear action
     */
    public void clear() {
        clearFindings();
        ViewManager.getInstance().clear();
        //clear line marker
        DaemonCodeAnalyzer.getInstance(currentPro).restart();
    }

    /**
     * remove all findings
     */
    private void clearFindings(){
        //delete findingx.xml
        String findingLocation = currentPro.getBasePath() +  "/threadsafe-results";
        File file = new File(findingLocation);
        if(file.exists()){
            FileManager.deleteDirectory(file);
        }
        //clear hash
        Iterator it = findingData.entrySet().iterator();
        while (it.hasNext()) {
            HashMap.Entry pair = (HashMap.Entry) it.next();
            Module m = (Module) pair.getKey();
            findingData.put(m, null);
        }
    }

    public void collapse() {
        ViewManager.getInstance().collapse();
    }

    public void expand() {
        ViewManager.getInstance().expand();
    }


    public void openEditorToolWindow(TSLocation className, String lineNum) {
        ViewManager.getInstance().openEditorToolWindow(className, lineNum);
    }


    public void callHierarchy(MouseEvent e, Finding finding) {
        ViewManager.getInstance().callHierarchy(e, finding);
    }

    /**
     * display help content
     * @param finding specific finding type to display
     */
    public void openUrl(Finding finding) {
        ViewManager.getInstance().openUrl(finding);
    }

    @Override
    public void showInBackground() {
        showInBackground = true;
    }

    @Override
    public void showInFront() {
        showInBackground = false;
    }

    @Override
    public void onCanceled() {
        setCanceled(true);

    }

    @Override
    public void onDetail() {

    }

    @Override
    public void onBackground() {
        showInBackground = true;
    }

    private static String WINDOW_ID = "ThreadSafe";
    private void openToolWindow(Project project) {
        if (project != null) {
            ToolWindowManager toolWindowManager = ToolWindowManager.getInstance(project);
            ToolWindow toolWindow = toolWindowManager.getToolWindow(WINDOW_ID);
            if (toolWindow != null) {
                toolWindow.show(null);
            }
        }
    }

    @Override
    public void start() {

    }

    @Override
    public void run(ThreadSafeCallable.ThreadSafeAnswer answer) {

    }

    @Override
    public void finish() {
        DebugController.debug("Plugin Manager: finished");

        if(isCanceled){
            return;
        }else{
            for(Module module: toAnalysesModules){
                updateModuleFinding(module);
            }
            closeDialog();
            displayTree();

            EventDispatchThreadHelper.invokeLater(new Runnable() {
                @Override
                public void run() {
                    //update line markers
                    DaemonCodeAnalyzer.getInstance(currentPro).restart();
                    openToolWindow(currentPro);
                }
            });
        }
    }

    /**
     * close analysing dialog
     */
    private void closeDialog(){
        if(getDialog() != null){
            if(getDialog().isShowing()){
                getDialog().dispose();
            }
        }
    }

    /**
     * update finding result
     * @param module module that been analysed
     */
    private void updateModuleFinding(Module module){
        String location = module.getProject().getBasePath()+ "/threadsafe-results/" + module.getName() + "/findings.xml";
        ArrayList<Finding> list = FileManager.parseFindings(module, location);
        if((list != null) && (list.size() > 0)){
            findingData.put(module, list);
        }
    }

    @Override
    public void err(ThreadSafeCallable.ThreadSafeAnswer answer) {

    }

    public Module getCurrentMod() {
        return currentMod;
    }

    public void setCurrentMod(Module currentMod) {
        this.currentMod = currentMod;
    }

    public TSDialog getDialog() {
        return dialog;
    }

    public void setDialog(TSDialog dialog) {
        this.dialog = dialog;
    }

    public boolean isCanceled() {
        return isCanceled;
    }

    public void setCanceled(boolean canceled) {
        isCanceled = canceled;
    }
}
