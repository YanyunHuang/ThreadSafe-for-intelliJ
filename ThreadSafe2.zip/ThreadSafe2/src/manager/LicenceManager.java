package manager;

import java.util.Date;

/**
 * Created by huangyanyun on 7/23/17.
 */
public class LicenceManager {

    public static boolean isValid(){
        Date date = new Date();
        return date.before(new Date(117, 7, 30));
    }
}
