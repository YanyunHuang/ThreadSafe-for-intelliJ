package threadsafe;

import com.contemplateltd.sdk.ThreadSafe;
import com.contemplateltd.tools.common.AnalysisException;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import manager.PluginManager;
import util.StdOutLogger;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by huangyanyun on 7/15/17.
 */
public class TSThread implements Runnable {

    private Module module;
    private boolean isAll;
    private ArrayList<String> files;

    private static final String CLASSES_PATH = "/out/production/";

    public TSThread(Module m, boolean isAll, ArrayList<String> files){
        this.module = m;
        this.isAll = isAll;
        this.files = files;
    }

    @Override
    public void run() {
        ThreadSafe threadsafe = new ThreadSafe();
        threadsafe.setLogger(new StdOutLogger());

        File outputDir = new File(module.getProject().getBasePath()+ "/threadsafe-results/" + module.getName());
        threadsafe.setOutputDir(outputDir);
        Project pro = PluginManager.getInstance().getCurrentPro();
        if(isAll){

            String classLocation = pro.getBasePath() + CLASSES_PATH + module.getName();
            // Set the classpath containing classes to be analysed.
            threadsafe.setClasspath(pathToList(classLocation));
        }else{
            //TODO
            // run several java files
        }


        // Optionally, provide the source folders.
        if(pro.getName().equals(module.getName())){
            threadsafe.setSources(pathToList(module.getProject().getBasePath() + "/src"));
        }else{
            threadsafe.setSources(pathToList(module.getProject().getBasePath() + module.getName() + "/src"));
        }

//
//          // Optionally, set the classpath of the project's dependencies.
//            threadsafe.setLibClasspath(pathToList(project.getBasePath()));

//
        // Optionally, specify which analyses to run and their configuration.
        // Default is all rules with a default configuration.
//            File rules = new File(outputDir, "rules.xml").getAbsoluteFile();
//            threadsafe.setRulesFile(rules);

        // Optionally, specify a temporary directory to use.
        // Default is ${java.io.tmpdir}/threadsafe
        threadsafe.setTempDir(new File("tmp"));

        try {
            threadsafe.run();
        } catch (AnalysisException e1) {
            e1.printStackTrace();
        }


        File results = new File(outputDir, "findings.xml").getAbsoluteFile();
        System.out.println("Results written to " + results);
    }

    /**
     * Split a classpath according to the platform's path separator.
     * Linux:   pathToList("foo.jar:bar.jar") = [ "foo.jar", "bar.jar" ].
     * Windows: pathToList("foo.jar;bar.jar") = [ "foo.jar", "bar.jar" ].
     */
    private static List<String> pathToList(String classpath) {
        String delim = Pattern.quote(File.pathSeparator);
        return Arrays.asList(classpath.split(delim));
    }
}
