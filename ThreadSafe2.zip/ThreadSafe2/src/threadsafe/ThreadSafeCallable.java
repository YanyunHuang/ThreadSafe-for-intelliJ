package threadsafe;

import com.contemplateltd.sdk.ThreadSafe;
import com.contemplateltd.tools.common.AnalysisException;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import manager.PluginManager;
import util.StdOutLogger;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.regex.Pattern;

/**
 * Created by huangyanyun on 7/6/17.
 */
public class ThreadSafeCallable implements Callable{

    private Module module;
    private boolean isAll;
    private ArrayList<String> files;

    private static final String CLASSES_PATH = "/out/production/";

    public ThreadSafeCallable(Module m, boolean isAll, ArrayList<String> files){
        this.module = m;
        this.isAll = isAll;
        this.files = files;
    }
    @Override
    public Object call() throws Exception {
        ThreadSafe threadsafe = new ThreadSafe();
        threadsafe.setLogger(new StdOutLogger());

        File outputDir = new File(module.getProject().getBasePath()+ "/threadsafe-results/" + module.getName());
        threadsafe.setOutputDir(outputDir);
        Project pro = PluginManager.getInstance().getCurrentPro();
        if(isAll){

            String classLocation = pro.getBasePath() + CLASSES_PATH + module.getName();
            // Set the classpath containing classes to be analysed.
            threadsafe.setClasspath(pathToList(classLocation));
        }else{
            //TODO
            // run several java files
        }


        // Optionally, provide the source folders.
        if(pro.getName().equals(module.getName())){
            threadsafe.setSources(pathToList(module.getProject().getBasePath() + "/src"));
        }else{
            threadsafe.setSources(pathToList(module.getProject().getBasePath() + module.getName() + "/src"));
        }

//
//          // Optionally, set the classpath of the project's dependencies.
//            threadsafe.setLibClasspath(pathToList(project.getBasePath()));

//
        // Optionally, specify which analyses to run and their configuration.
        // Default is all rules with a default configuration.
//            File rules = new File(outputDir, "rules.xml").getAbsoluteFile();
//            threadsafe.setRulesFile(rules);

        // Optionally, specify a temporary directory to use.
        // Default is ${java.io.tmpdir}/threadsafe
        threadsafe.setTempDir(new File("tmp"));

        try {
            threadsafe.run();
        } catch (AnalysisException e1) {
            e1.printStackTrace();
        }


        File results = new File(outputDir, "findings.xml").getAbsoluteFile();
        System.out.println("Results written to " + results);

        return new ThreadSafeAnswer(module, true, 100, null);
    }

    /**
     * Split a classpath according to the platform's path separator.
     * Linux:   pathToList("foo.jar:bar.jar") = [ "foo.jar", "bar.jar" ].
     * Windows: pathToList("foo.jar;bar.jar") = [ "foo.jar", "bar.jar" ].
     */
    private static List<String> pathToList(String classpath) {
        String delim = Pattern.quote(File.pathSeparator);
        return Arrays.asList(classpath.split(delim));
    }

    public class ThreadSafeAnswer{
        private boolean complete;
        private int progress;
        private Error err;
        private Module module;

        public ThreadSafeAnswer(Module m, boolean completed, int progress, Error err){
            this.setModule(m);
            this.complete = completed;
            this.progress = progress;
            this.err = err;
        }

        public boolean isComplete() {
            return complete;
        }

        public void setComplete(boolean complete) {
            this.complete = complete;
        }

        public int getProgress() {
            return progress;
        }

        public void setProgress(int progress) {
            this.progress = progress;
        }

        public Error getErr() {
            return err;
        }

        public void setErr(Error err) {
            this.err = err;
        }

        public Module getModule() {
            return module;
        }

        public void setModule(Module module) {
            this.module = module;
        }
    }
}
