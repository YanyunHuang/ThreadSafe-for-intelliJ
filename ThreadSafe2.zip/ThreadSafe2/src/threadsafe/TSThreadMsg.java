package threadsafe;

/**
 * Created by huangyanyun on 7/15/17.
 */
public class TSThreadMsg {

    private boolean isFinished = false;
    private int SUCCESS = 1;
    int FAIL = 2;

    private int result; //0-default 1-success 2-fail
    private String msg; // err msg

    public TSThreadMsg(boolean isFinished, int result, String msg){
        this.setFinished(isFinished);
        this.setResult(result);
        this.setMsg(msg);
    }

    public boolean isFinished() {
        return isFinished;
    }

    public void setFinished(boolean finished) {
        isFinished = finished;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }
}
