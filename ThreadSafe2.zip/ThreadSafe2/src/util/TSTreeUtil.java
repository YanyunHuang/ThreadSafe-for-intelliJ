package util;

import com.intellij.util.ui.ColumnInfo;
import gui.TSTreeColumnInfo;
import gui.TreeNodeData;
import model.xml.Finding;
import org.jetbrains.annotations.Nullable;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * Created by huangyanyun on 7/9/17.
 */
public class TSTreeUtil {

    public static ColumnInfo[] getColume(){

        ColumnInfo[] columnInfos = new ColumnInfo[]{
                new TSTreeColumnInfo("Description"),
                new ColumnInfo<DefaultMutableTreeNode, String>("Resource") {
                    @Nullable
                    @Override
                    public String valueOf(DefaultMutableTreeNode defaultRegisterNode) {

                        String value = "";
                        if(defaultRegisterNode.isLeaf()){
                            TreeNodeData content = (TreeNodeData)defaultRegisterNode.getUserObject();
                            value = ((Finding) (content.getContent())).getLocations().get(0).getFileName();
                        }else {
                            value = "";
                        }
                        return value;
                    }
                },
                new ColumnInfo<DefaultMutableTreeNode, String>("Path") {
                    @Nullable
                    @Override
                    public String valueOf(DefaultMutableTreeNode defaultRegisterNode) {

                        String value = "";
                        if(defaultRegisterNode.isLeaf()){
                            TreeNodeData content = (TreeNodeData)defaultRegisterNode.getUserObject();
                            value = ((Finding) content.getContent()).getLocations().get(0).getPath();
                        }else {
                            value = "";
                        }
                        return value;
                    }
                }
        };

        return columnInfos;
    }
}
