package util;

import com.contemplateltd.tools.util.Logger;

public class StdOutLogger implements Logger {

    @Override
    public void info(String message) {
        System.out.println("INFO: "+ message);
    }

    @Override
    public void warn(String message) {
        System.out.println("WARN: "+ message);
    }

    @Override
    public void error(String message) {
        System.out.println("ERROR: "+ message);
    }

    @Override
    public void error(String message, Throwable cause) {
        System.out.println("ERROR: "+ message);
        if (cause != null) {
            cause.printStackTrace(System.out);
        }
    }

}
