package util;

import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.ProblemHighlightType;
import com.intellij.codeInspection.QuickFix;
import com.intellij.lang.annotation.ProblemGroup;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.editor.colors.TextAttributesKey;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiDocumentManager;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import model.xml.Finding;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Created by huangyanyun on 7/15/17.
 */
public class ExtendedProblemDescriptor implements ProblemDescriptor, ProblemGroup {

    @NotNull
    private final PsiFile psiFile;

    private PsiElement psiElement;

    /**
     * This is the line as reported by FindBugs, rather than that computed by IDEA.
     */
    private final int line;

    @NotNull
    private final Finding finding;


    public ExtendedProblemDescriptor(@NotNull final PsiFile psiFile, @NotNull final Finding finding) {
        this.psiFile = psiFile;
        this.finding = finding;
        line = Integer.parseInt(finding.getLocations().get(0).getLine()) - 1;
    }

    @NotNull
    public Finding getFinding() {
        return finding;
    }

    @Override
    public PsiElement getPsiElement() {
        if (psiElement != null) {
            return psiElement;
        }
        psiElement = getElementAtLine(psiFile, line);
        return psiElement;
    }

    @Override
    public PsiElement getStartElement() {
        return getPsiElement();
    }

    @Override
    public PsiElement getEndElement() {
        return getPsiElement();
    }

    @Override
    public TextRange getTextRangeInElement() {
        return null;
    }

    @Override
    public int getLineNumber() {
        return line;
    }

    @NotNull
    @Override
    public ProblemHighlightType getHighlightType() {
        return ProblemHighlightType.GENERIC_ERROR_OR_WARNING;
    }

    @Override
    public boolean isAfterEndOfLine() {
        return false;
    }

    @Override
    public void setTextAttributes(TextAttributesKey key) {

    }

    @Nullable
    @Override
    public ProblemGroup getProblemGroup() {
        return this;
    }

    @Override
    public void setProblemGroup(@Nullable ProblemGroup problemGroup) {

    }

    @Override
    public boolean showTooltip() {
        return true;
    }

    @NotNull
    @Override
    public String getDescriptionTemplate() {
        return null;
    }

    @Nullable
    @Override
    public QuickFix[] getFixes() {
        return new QuickFix[0];
    }

    @Nullable
    @Override
    public String getProblemName() {
        return null;
    }

    @NotNull
    public PsiFile getPsiFile() {
        return psiFile;
    }

    @Nullable
    public static PsiElement getElementAtLine(@NotNull final PsiFile file, final int line) {
        //noinspection ConstantConditions
        if (file == null) {
            return null;
        }

        final Document document = PsiDocumentManager.getInstance(file.getProject()).getDocument(file);
        if(line < 1){

        }

        PsiElement element = null;
        try {
            if (document != null) {
                final int offset = document.getLineStartOffset(line);
                element = file.getViewProvider().findElementAt(offset);
                if (element != null) {
                    if (document.getLineNumber(element.getTextOffset()) != line) {
                        element = element.getNextSibling();
                    }
                }
            }
        } catch (@NotNull final IndexOutOfBoundsException ignore) {
        }

        return element;
    }
}
