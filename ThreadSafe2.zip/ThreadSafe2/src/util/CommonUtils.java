package util;

import model.ui.enums.TreeItemType;
import model.xml.Finding;
import model.xml.enums.Category;
import model.xml.enums.FindingType;
import model.xml.enums.LabelType;
import model.xml.enums.Severity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

/**
 * Created by huangyanyun on 6/7/17.
 */
public final class CommonUtils {

    public static Severity getTypeSeverity(FindingType type){

        switch(type){
            case CCE_CC_SYNC_ON_VIEW:
            case CCE_CC_GUARD_USAGE:
            case CCE_CC_SUGGEST_PUTIFABSENT:
                return Severity.Minor;
            default:
                return Severity.Major;

        }
    }

    public static Category getTypeCategory(FindingType type){

        switch(type){
            case CCE_BC_CONCURRENT_MODIFICATION:
                return Category.Bad_practice;
            case CCE_FF_VOLATILE:
                return Category.Immutability;
            case CCE_CC_SUGGEST_PUTIFABSENT:
            case CCE_CC_ITER_VIEW_BOTH_LOCKS:
            case CCE_CC_ITER_VIEW_WRONG_LOCK:
            case CCE_CC_ITER_VIEW_NO_LOCK:
            case CCE_CC_NON_ATOMIC_CP:
            case CCE_CC_NON_ATOMIC_GCP:
            case CCE_CC_UNSAFE_CONTENT:
            case CCE_CC_SYNC_ON_VIEW:
            case CCE_CC_GUARD_USAGE:
            case CCE_CC_UNSAFE_REPLACEMENT:
            case CCE_CC_UNSAFE_ITERATION:
                return Category.Collections;
            default:
                return Category.Locking;

        }
    }

    public static String getTypeName(FindingType type){

        switch(type){
            case CCE_LK_LOCKED_BLOCKING_CALLS:
                return "Call to blocking methods while holding lock";
            case CCE_BC_CONCURRENT_MODIFICATION:
                return "ConcurrentModificationException caught";
            case CCE_DL_DEADLOCK:
                return "Deadlock due to circularity in lock dependencies";
            case CCE_CC_FIELD_LOCK_WRITE:
                return "Field reassigned while holding a lock on its value";
            case CCE_CC_SUGGEST_PUTIFABSENT:
                return "Get/check/put used rather than putIfAbsent";
            case CCE_RA_INVALID_GUARD:
                return "Guard expression is not valid";
            case CCE_RA_GUARD_NOT_FINAL:
                return "Guard is not final";
            case CCE_RA_GUARDED_BY_VIOLATED:
                return "GuardBy annotation violated";
            case CCE_SL_INCONSISTENT_COL:
                return "Inconsistent synchronization of accesses to a collection";
            case CCE_SL_INCONSISTENT:
                return "Inconsistent synchronization of accesses to a field";
            case CCE_CC_ITER_VIEW_BOTH_LOCKS:
                return "Iterating over a synchronized collection view while holding a lock on the view";
            case CCE_CC_ITER_VIEW_WRONG_LOCK:
                return "Iteration over collection view while not locking on the backing collection";
            case CCE_LK_UNRELEASED_ON_EXN:
                return "Lock not released when method throws out an exception";
            case CCE_SL_MIXED_COL:
                return "Mixed synchronization of accesses to a collection stored in a field";
            case CCE_SL_MIXED:
                return "Mixed synchronization of accesses to a field";
            case CCE_CC_ITER_VIEW_NO_LOCK:
                return "No lock help while iterating on a synchronized collection view";
            case CCE_CC_NON_ATOMIC_CP:
                return "Non atomic Check/Put on ThreadSafe collection";
            case CCE_CC_NON_ATOMIC_GCP:
                return "Non atomic use of Get/Check/Put";
            case CCE_CC_UNSAFE_CONTENT:
                return "Shared non ThreadSafe content";
            case CCE_CC_SYNC_ON_VIEW:
                return "Synchronizing on a collection view";
            case CCE_CC_REUSEDOBJ_SYNC:
                return "Synchronizing on reusable objects";
            case CCE_CC_GUARD_USAGE:
                return "ThreadSafe collection consistently guarded";
            case CCE_CC_UNSAFE_REPLACEMENT:
                return "ThreadSafe collection replaced by potentially unsafe collection";
            case CCE_CC_UNSAFE_ITERATION:
                return "Unsafe iteration over synchronized collection";
            case CCE_CC_CALLBACK_ACCESS:
                return "Unsynchronized access to field from asynchronously invoked method";
            case CCE_LK_REPLACE_WITH_TRYLOCK:
                return "Use of isLock() and lock() rather tryLock()";
            case CCE_FF_VOLATILE:
                return "Violate field only written in initialization";

        }

        return null;
    }

    public static String getLabelString(String label) {
        try{
            LabelType type = LabelType.valueOf(label);

            switch(type) {
                case relevant_sync_read:
                    return "Synchronized read";
                case relevant_sync_write:
                    return "Synchronized write";
                case guard_field:
                    return "guard_field";
                case guard_type:
                    return "guard_type";
                case relevant_unsync_read:
                    return "Unsynchronized read";
                case async_entrypoint:
                    return "Asynchronously invoked method";
                case relevant_unsync_write:
                    return "Unsynchronized write";
                case blockingremove:
                    return "Blocking removal from queue";
                case insert:
                    return "Insertion into queue";
                case replaced_field:
                    return "The replaced field";
                case safe_assignment:
                    return "Thread-safe collection";
                case unsafe_assignment:
                    return "Non-thread-safe collection";
                case put:
                    return "Put into collection";
                case get:
                    return "Get from map";
                case check:
                    return "Check for null value";
                case creation:
                    return "Synchronized collection";
                case collection_lock:
                    return "Lock acquired on backing collection";
                case view_lock:
                    return "Lock acquired on view";
                case lock:
                    return "Lock acquired";
                case is_locked:
                    return "Check for lock";
                case mutation:
                    return "Non-thread-safe collection modified";
                case leaked_via:
                    return "Thread-safe collection";
                default:
                    return label.toString();
            }
            }catch(IllegalArgumentException e){
            return label;
        }
    }

    public static HashMap<FindingType,ArrayList<Finding>> sortFindingsByType(ArrayList<Finding> list) {
        LinkedHashMap<FindingType, ArrayList<Finding>> map = new LinkedHashMap<FindingType, ArrayList<Finding>>();
        for(int index = 0; index < list.size(); index ++){
            Finding finding = list.get(index);
            FindingType type = finding.getType();
            if(map.containsKey(type)){
                ArrayList<Finding> l = map.get(type);
                l.add(finding);
                map.put(type, l);
            }else{
                ArrayList<Finding> l = new ArrayList<Finding>();
                l.add(finding);
                map.put(type, l);
            }
        }
        return map;
    }


//    public final static String JAVA_TAIL = ".java";
    public static HashMap<String,ArrayList<Finding>> sortFindingsByResource(ArrayList<Finding> list) {
        LinkedHashMap<String, ArrayList<Finding>> map = new LinkedHashMap<String, ArrayList<Finding>>();
        for(int index = 0; index < list.size(); index ++){
            Finding finding = list.get(index);
            String resource = finding.getLocations().get(0).getPath();
            if(map.containsKey(resource)){
                ArrayList<Finding> l = map.get(resource);
                l.add(finding);
                map.put(resource, l);
            }else{
                ArrayList<Finding> l = new ArrayList<Finding>();
                l.add(finding);
                map.put(resource, l);
            }
        }
        return map;
    }

    public static HashMap<Severity,ArrayList<Finding>> sortFindingsBySeverity(ArrayList<Finding> list) {

        LinkedHashMap<Severity, ArrayList<Finding>> map = new LinkedHashMap<Severity, ArrayList<Finding>>();
        for(int index = 0; index < list.size(); index ++){
            Finding finding = list.get(index);
            Severity type = CommonUtils.getTypeSeverity(finding.getType());
            if(map.containsKey(type)){
                ArrayList<Finding> l = map.get(type);
                l.add(finding);
                map.put(type, l);
            }else{
                ArrayList<Finding> l = new ArrayList<Finding>();
                l.add(finding);
                map.put(type, l);
            }
        }
        return map;
    }

    public static String createSeverityIcon(FindingType type){

        String iconFile = null;
        switch(CommonUtils.getTypeSeverity(type)){
            case Blocker:
                iconFile = "/icons/obj16/blocker.png";
                break;
            case Critical:
                iconFile = "/icons/obj16/critical.png";
                break;
            case Major:
                iconFile = "/icons/obj16/major.png";
                break;
            case Minor:
                iconFile = "/icons/obj16/minor.png";
                break;
            case Info:
                iconFile = "/icons/obj16/info.png";
                break;
        }
        return iconFile;

    }

    public static String createProjectIcon(TreeItemType type){

        String iconFile = null;
//        IconLoader.getIcon("/nodes/extractedFolder.png");
        switch(type){
            case Project:
                iconFile = "/icons/intelli/project.png";
                break;
            case Folder:
                iconFile = "/icons/intelli/folder.png";
                break;
            case Package:
                iconFile = "/icons/intelli/sourceFolder.png";
                break;
            case File:
                iconFile = "/icons/intelli/java.png";
                break;
        }
        return iconFile;

    }

    public static int getSeverityNum(Severity seve, ArrayList<Finding> findings) {

        int result = 0;
        for(int i = 0; i < findings.size(); i++){
            if(getTypeSeverity(findings.get(i).getType()).equals(seve)){
                result += 1;
            }
        }
        return result;
    }
}
