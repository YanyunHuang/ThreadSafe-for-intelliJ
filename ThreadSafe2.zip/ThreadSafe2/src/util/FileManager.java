package util;

import com.intellij.openapi.module.Module;
import model.xml.Finding;

import java.util.ArrayList;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
import javax.xml.parsers.*;
import java.io.*;

/**
 * Created by huangyanyun on 6/1/17.
 * Used to read or write file
 */
public final class FileManager {

    /**
     * @param fileName path to parse source
     * @return finding list
     */
    public static ArrayList<Finding> parseFindings(Module module, String fileName){

        ArrayList<Finding> findings = new ArrayList<Finding>();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try{
            DocumentBuilder builder = factory.newDocumentBuilder();

            StringBuilder stringBuilder = parseXmlToString(fileName);
            ByteArrayInputStream input =  new ByteArrayInputStream(stringBuilder.toString().getBytes("UTF-8"));
            Document doc = builder.parse(input);

            String name = "";
            boolean isProject = module.getName().equals(module.getProject().getName());
            if(isProject){
                name = module.getName();
            }else{
                name = module.getProject().getName() + "/" + module.getName();
            }
            findings = ParseManager.parseDocToFindings(module, name, doc);

        }catch (ParserConfigurationException|SAXException|IOException e){
            System.out.print(e);
        }

        return findings;

    }

    /**
     *
     * @param fileName
     * @return StringBuilder
     */
    private static StringBuilder parseXmlToString(String fileName){

        StringBuilder sb = new StringBuilder();

        try{
            InputStream is = new FileInputStream(fileName);
            BufferedReader buf = new BufferedReader(new InputStreamReader(is));

            String line = buf.readLine();

            while(line != null) {
                sb.append(line).append("\n");
                line = buf.readLine();
            }

        }catch (IOException e){
            System.out.print(e);
        }

        return sb;
    }

    public static boolean deleteDirectory(File directory) {
        if(directory.exists()){
            File[] files = directory.listFiles();
            if(null!=files){
                for(int i=0; i<files.length; i++) {
                    if(files[i].isDirectory()) {
                        deleteDirectory(files[i]);
                    }
                    else {
                        files[i].delete();
                    }
                }
            }
        }
        return(directory.delete());
    }
}
