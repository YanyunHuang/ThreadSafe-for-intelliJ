package util;

/**
 * Created by huangyanyun on 6/19/17.
 */
public class DebugController {

    private static final boolean DEBUG_TAG = true;

    public static void debug(String msg){

        if(DEBUG_TAG){
            System.out.println(msg);
        }

    }
}
