package util;

import java.awt.*;

/**
 * Created by huangyanyun on 7/15/17.
 */
public class EventDispatchThreadHelper {

    public static void invokeLater(final Runnable runnable) {
        if (!EventQueue.isDispatchThread()) {
            @SuppressWarnings({"ThrowableInstanceNeverThrown"})
            final CallerStack caller = new CallerStack();
            final Runnable wrapper = new Runnable() {
                public void run() {
                    try {
                        runnable.run();
                    } catch (final RuntimeException e) {
                        CallerStack.initCallerStack(e, caller);
                        throw e;
                    } catch (final Error e) {
                        CallerStack.initCallerStack(e, caller);
                        throw e;
                    }
                }
            };
            EventQueue.invokeLater(wrapper);
        } else {
            // we are already in EventDispatcherThread.. Runnable can be called inline
            runnable.run();
        }
    }
}
