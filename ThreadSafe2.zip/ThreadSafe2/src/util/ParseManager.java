package util;

import com.intellij.openapi.module.Module;
import com.intellij.psi.JavaPsiFacade;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiManager;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.util.PsiTypesUtil;
import com.intellij.psi.util.PsiUtil;
import groovy.lang.GroovyClassLoader;
import intellij.LineNumberResolver;
import intellij.Tools;
import manager.PluginManager;
import model.xml.*;
import model.xml.enums.FindingType;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.util.ArrayList;

/**
 * Created by huangyanyun on 6/2/17.
 * parse xml to class
 */
final class ParseManager {

    private final static String FINDING_TAG = "finding";
    private final static String TYPE_TAG = "type";
    private final static String LOCATIONS_TAG = "locations";
    private final static String INFO_TAG = "info";
    private final static String FIELD_TAG = "field";
    private final static String INSTRUCTION_TAG = "instruction";
    private final static String CLASS_TAG = "class";
    private final static String CLASSNAME_TAG = "className";
    private final static String NAME_TAG = "name";
    private final static String KEY_TAG = "key";
    private final static String FILENAME_TAG = "filename";
    private final static String LINE_TAG = "line";
    private final static String METHOD_TAG = "method";
    private final static String OFFSET_TAG = "offset";
    private final static String DESC_TAG = "desc";
    private final static String LABEL_TAG = "label";
    private final static String MESSAGE_TAG = "message";
    private final static String GUARDS_TAG = "guards";
    private final static String ACCESSES_TAG = "accesses";
    private final static String VALUE_TAG = "value";
    private final static String TYPEREF_TAG = "typeRef";
    private final static String INTRINSIC_TAG = "intrinsic";
    private final static String GUARDPATH_TAG = "guardPath";
    private final static String TARGETPATH_TAG = "targetPath";
    private final static String LOCATIONREF_TAG = "locationRef";
    private final static String LOCATION_TAG = "location";
    private final static String ACCESSGUARDS_TAG = "accessGuards";
    private final static String GUARDREF_TAG = "guardRef";
    private final static String STATUS_TAG = "status";

    static ArrayList<Finding> parseDocToFindings(Module m, String proName, Document doc) {

        if(doc == null){
            return null;
        }

        ArrayList<Finding> findings = new ArrayList<Finding>();
        NodeList nList = doc.getElementsByTagName(FINDING_TAG);

        if ((nList != null) && (nList.getLength() > 0)) {
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                Finding finding = parseFinding(m, proName, nNode);
                //set problem location
                finding.getLocations().get(0).setProblemLocation(true);
                if (finding != null) {
                    findings.add(finding);
                }
            }
        }
        return findings;
    }

    private static Element convertElement(Node item) {

        if (item == null) {
            return null;
        }
        if (item.getNodeType() != Node.ELEMENT_NODE) {
            return null;
        } else {
            return (Element) item;
        }
    }

    private static String getAttribute(Element e, String tag) {

        if((e == null) || (tag == null) || (!e.hasAttribute(tag))){
            return null;
        }
        return e.getAttribute(tag);
    }

    private static NodeList getElements(Element e, String tag) {

        if((e == null) || (tag == null)){
            return null;
        }
        return e.getElementsByTagName(tag);
    }

    private static Node getElement(Element e, String tag) {

        if((e == null) || (tag == null)){
            return null;
        }
        NodeList list = e.getElementsByTagName(tag);
        if ((list == null) || (list.getLength() == 0)){
            return null;
        }
        return list.item(0);
    }

    private static Finding parseFinding(Module m, String proName, Node item) {

        if(item == null){
            return null;
        }
        Element eElement = convertElement(item);

        if (eElement == null) {
            return null;
        }

        Finding finding = new Finding();

        String findTypeString = getAttribute(eElement, TYPE_TAG);
        if (findTypeString != null) {
            finding.setType(FindingType.valueOf(findTypeString));
        }

        Node locationsNode = getElement(eElement, LOCATIONS_TAG);
        if(locationsNode != null){
            ArrayList<TSLocation> locations = parseLocations(m, proName, locationsNode);
            if ((locations != null) && (locations.size() > 0)) {
                finding.setLocations(locations);
            }
        }

        Node infoNode = getElement(eElement, INFO_TAG);
        if (infoNode != null) {
            TSInfo info = parseInfo(infoNode);
            if (info != null) {
                finding.setInfo(info);
            }
        }
        return finding;
    }

    private static ArrayList<TSLocation> parseLocations(Module m, String proName, Node item) {

        if(item == null){
            return null;
        }
        Element eElement = convertElement(item);

        if (eElement == null) {
            return null;
        }
        ArrayList<TSLocation> locations = new ArrayList<TSLocation>();

        NodeList fieldNodes = getElements(eElement, FIELD_TAG);
        if ((fieldNodes != null) && (fieldNodes.getLength() > 0)) {
            ArrayList<Field> fields = parseFields(m, proName, fieldNodes);
            if ((fields != null) && (fields.size() > 0)) {
                locations.addAll(fields);
            }
        }

        NodeList instructionNodes = getElements(eElement, INSTRUCTION_TAG);
        if ((instructionNodes != null) && (instructionNodes.getLength() > 0)) {
            ArrayList<Instruction> instructions = parseInstructions(proName, instructionNodes);
            if ((instructions != null) && (instructions.size() > 0)) {
                locations.addAll(instructions);
            }
        }

        NodeList classNodes = getElements(eElement, CLASS_TAG);
        if ((classNodes != null) && (classNodes.getLength() > 0)) {
            ArrayList<TSClass> classes = parseClasses(proName, classNodes);
            if ((classes != null) && (classes.size() > 0)) {
                locations.addAll(classes);
            }
        }

        NodeList methodsNodes = getElements(eElement, METHOD_TAG);
        if ((methodsNodes != null) && (methodsNodes.getLength() > 0)) {
            ArrayList<TSMethod> methods = parseTFMethods(proName, methodsNodes);
            if ((methods != null) && (!methods.isEmpty())) {
                locations.addAll(methods);
            }
        }
        return locations;

    }

    private static ArrayList<Field> parseFields(Module m, String proName, NodeList nodes) {

        if((nodes == null) || (nodes.getLength() == 0)){
            return null;
        }

        ArrayList<Field> fields = new ArrayList<Field>();
        for (int temp = 0; temp < nodes.getLength(); temp++) {

            Element eElement = convertElement(nodes.item(temp));
            if (eElement == null) {
                continue;
            }
            Field field = new Field();
            field.setClassName(Tools.getClassFile(getAttribute(eElement, CLASSNAME_TAG)));
            field.setPath(proName + "/src/" + getAttribute(eElement, CLASSNAME_TAG).replace(".", "/") + ".java");
            field.setModuleName(m);
            field.setFileName(getAttribute(eElement, FILENAME_TAG));
            field.setName(getAttribute(eElement, NAME_TAG));
            field.setType(getAttribute(eElement, TYPE_TAG));
            field.setKey(getAttribute(eElement, KEY_TAG));
            field.setLabel(getAttribute(eElement, LABEL_TAG));

            String lineNum = getAttribute(eElement, LINE_TAG);
            field.setLine(lineNum);

//            if((lineNum == null) || (lineNum.equals("0"))){
//                EventDispatchThreadHelper.invokeLater(new Runnable() {
//                    @Override
//                    public void run() {
//                        String parseLine = Tools.findField(field.getClassName(), field.getName());
//                        field.setLine(parseLine);
//                    }
//                });
//
//            }
            fields.add(field);
        }
        return fields;

    }

    private static ArrayList<Instruction> parseInstructions(String proName, NodeList nodes) {

        if((nodes == null) || (nodes.getLength() == 0)){
            return null;
        }

        ArrayList<Instruction> instructions = new ArrayList<Instruction>();
        for (int temp = 0; temp < nodes.getLength(); temp++) {

            Element eElement = convertElement(nodes.item(temp));
            if (eElement == null) {
                continue;
            }
            Instruction instruction = new Instruction();
            instruction.setClassName(Tools.getClassFile(getAttribute(eElement, CLASSNAME_TAG)));
            instruction.setPath(proName + "/src/" + getAttribute(eElement, CLASSNAME_TAG).replace(".", "/") + ".java");
            instruction.setFileName(getAttribute(eElement, FILENAME_TAG));
            instruction.setLine(getAttribute(eElement, LINE_TAG));
            instruction.setMethod(getAttribute(eElement, METHOD_TAG));
            instruction.setOffset(getAttribute(eElement, OFFSET_TAG));
            instruction.setKey(getAttribute(eElement, KEY_TAG));
            instruction.setDesc(getAttribute(eElement, DESC_TAG));
            instruction.setLabel(getAttribute(eElement, LABEL_TAG));

            instructions.add(instruction);

        }
        return instructions;

    }

    private static ArrayList<TSClass> parseClasses(String proName, NodeList nodes) {

        if((nodes == null) || (nodes.getLength() == 0)){
            return null;
        }

        ArrayList<TSClass> classes = new ArrayList<TSClass>();
        for (int temp = 0; temp < nodes.getLength(); temp++) {

            Element eElement = convertElement(nodes.item(temp));
            if (eElement == null) {
                continue;
            }
            TSClass tsClass = new TSClass();
            tsClass.setClassName(Tools.getClassFile(getAttribute(eElement, CLASSNAME_TAG)));
            tsClass.setPath(proName + "/src/" + getAttribute(eElement, NAME_TAG).replace(".", "/") + ".java");
            tsClass.setFileName(getAttribute(eElement, FILENAME_TAG));
            tsClass.setLabel(getAttribute(eElement, LABEL_TAG));
            tsClass.setKey(getAttribute(eElement, KEY_TAG));

            classes.add(tsClass);
        }
        return classes;

    }

    private static ArrayList<TSMethod> parseTFMethods(String proName, NodeList nodes) {

        if((nodes == null) || (nodes.getLength() == 0)){
            return null;
        }

        ArrayList<TSMethod> methods = new ArrayList<TSMethod>();
        for (int temp = 0; temp < nodes.getLength(); temp++) {

            Element eElement = convertElement(nodes.item(temp));
            if (eElement == null) {
                continue;
            }
            TSMethod tsMethod = new TSMethod();

            tsMethod.setName(getAttribute(eElement, NAME_TAG));
            tsMethod.setFileName(getAttribute(eElement, FILENAME_TAG));
            tsMethod.setLabel(getAttribute(eElement, LABEL_TAG));
            tsMethod.setKey(getAttribute(eElement, KEY_TAG));
            tsMethod.setClassName(Tools.getClassFile(getAttribute(eElement, CLASSNAME_TAG)));
            tsMethod.setPath(proName + "/src/" + getAttribute(eElement, CLASSNAME_TAG).replace(".", "/") + ".java");
            tsMethod.setDesc(getAttribute(eElement, DESC_TAG));
            tsMethod.setLine(getAttribute(eElement, LINE_TAG));

            methods.add(tsMethod);
        }
        return methods;

    }

    private static TSInfo parseInfo(Node item) {

        if(item == null){
            return null;
        }
        Element eElement = convertElement(item);
        if (eElement == null) {
            return null;
        }

        TSInfo info = new TSInfo();

        Node msgNode = getElement(eElement, MESSAGE_TAG);
        if (msgNode != null) {
            Message msg = parseMessage(msgNode);
            if (msg != null) {
                info.setMessage(msg);
            }
        }

        NodeList accessNodes = getElements(eElement, ACCESSES_TAG);
        if ((accessNodes != null) && (accessNodes.getLength() > 0)) {
            ArrayList<Access> accesses = parseAccesses(accessNodes);
            if ((accesses != null) && (accesses.size() > 0)) {
                info.setAccesses(accesses);
            }
        }

        NodeList guardRelativesNodes = getElements(eElement, GUARDS_TAG);
        if ((guardRelativesNodes != null) && (guardRelativesNodes.getLength() > 0)) {
            ArrayList<GuardRelative> guardRelatives = parseGuards(guardRelativesNodes);
            if ((guardRelatives != null) && (guardRelatives.size() > 0)) {
                info.setGuards(guardRelatives);
            }
        }
        return info;
    }


    private static Message parseMessage(Node item) {

        if(item == null){
            return null;
        }

        Element eElement = convertElement(item);
        if (eElement == null) {
            return null;
        }

        Message msg = new Message();
        msg.setValue(getAttribute(eElement, VALUE_TAG));
        return msg;
    }

    private static ArrayList<GuardRelative> parseGuards(NodeList nodes) {

        if((nodes == null) || (nodes.getLength() == 0)){
            return null;
        }
        ArrayList<GuardRelative> guards = new ArrayList<GuardRelative>();
        for (int temp = 0; temp < nodes.getLength(); temp++) {

            Element eElement = convertElement(nodes.item(temp));
            if (eElement == null) {
                continue;
            }

            GuardRelative guardRelative = new GuardRelative();

            guardRelative.setTypeRef(getAttribute(eElement, TYPEREF_TAG));
            guardRelative.setKey(getAttribute(eElement, KEY_TAG));
            guardRelative.setIntrinsic(getAttribute(eElement, INTRINSIC_TAG));

            Node guardPathNode = getElement(eElement, GUARDPATH_TAG);
            if ((guardPathNode != null) && (guardPathNode.hasAttributes())) {
                GuardPath guardPath = parseGuardPath(guardPathNode);
                if (guardPath != null) {
                    guardRelative.setGuardPath(guardPath);
                }
            }

            Node targetPathNode = getElement(eElement, TARGETPATH_TAG);
            if ((targetPathNode != null) && (targetPathNode.hasAttributes())) {
                TargetPath targetPath = parseTargetPath(targetPathNode);
                if (targetPath != null) {
                    guardRelative.setTargetPath(targetPath);
                }
            }
            guards.add(guardRelative);
        }
        return guards;
    }

    private static GuardPath parseGuardPath(Node item) {

        if(item == null){
            return null;
        }
        Element e = convertElement(item);
        if (e == null) {
            return null;
        }
        GuardPath guardPath = new GuardPath();
        Node locationRefNode = getElement(e, LOCATIONREF_TAG);

        if (locationRefNode != null) {
            Element refElement = convertElement(locationRefNode);
            if (refElement != null) {
                LocationRef ref = new LocationRef();
                ref.setKey(getAttribute(refElement, LOCATIONREF_TAG));
                guardPath.setLocationRef(ref);
            }
        }
        return guardPath;
    }

    private static TargetPath parseTargetPath(Node item){
        //TODO
        return null;
    }


    private static ArrayList<Access> parseAccesses(NodeList nodes){

        if((nodes == null) || (nodes.getLength() == 0)){
            return null;
        }
        ArrayList<Access> accesses = new ArrayList<Access>();
        for (int temp = 0; temp < nodes.getLength(); temp++) {
            Element eElement = convertElement(nodes.item(temp));
            if (eElement == null) {
                continue;
            }

            Access access = new Access();
            access.setLocation(getAttribute(eElement, LOCATION_TAG));
            access.setType(getAttribute(eElement, TYPE_TAG));

            Node accessGuardsNode = getElement(eElement, ACCESSGUARDS_TAG);
            if (accessGuardsNode != null) {
                AccessGuard accessGuard = parseAccessGuard(accessGuardsNode);
                if(accessGuard != null){
                    access.setAccessGuards(accessGuard);
                }
            }
            accesses.add(access);
        }
        return accesses;
    }

    private static AccessGuard parseAccessGuard(Node item){

        if((item != null) && (item.hasChildNodes())){
            AccessGuard accessGuard = new AccessGuard();
            Element eElement = convertElement(item);
            if (eElement == null) {
                return null;
            }

            Node guardRefNode = getElement(eElement, GUARDREF_TAG);
            if (guardRefNode != null) {
                Element e = convertElement(guardRefNode);
                if(e != null){
                    GuardRef guardRef = new GuardRef();
                    guardRef.setKey(getAttribute(e, KEY_TAG));
                    guardRef.setStatus(getAttribute(e, STATUS_TAG));

                    accessGuard.setGuardRef(guardRef);
                }
            }
            return accessGuard;
        }
        return null;
    }

}
