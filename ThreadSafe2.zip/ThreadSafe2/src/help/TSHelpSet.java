package help;

import util.DebugController;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.help.event.HelpSetEvent;
import javax.help.event.HelpSetListener;
import java.net.URL;
import java.util.Hashtable;

/**
 * Created by huangyanyun on 7/11/17.
 */
public class TSHelpSet {

    private HelpSet mainHS;
    private HelpBroker mainHB;
    private ClassLoader myLoader;
    private Hashtable clTable;
    private static boolean on12;
    private static TSHelpSet instance;

    public TSHelpSet(){
        try {
            ClassLoader cl = getMyLoader();
            URL url = HelpSet.findHelpSet(cl, "contemplate-help/HelpSet.hs");
            mainHS = new HelpSet(cl, url);
        } catch (Exception ee) {
            System.out.println ("Help Set not found");
            return;
        }
        mainHB = mainHS.createHelpBroker();

        // Add a button to show the help
        initializeMasterHS();
//        initializeGUI();
    }

    private ClassLoader getMyLoader() {
        ClassLoader back;
        back = this.getClass().getClassLoader();
        DebugController.debug("current loader is "+back);
        return back;
    }

    private void initializeMasterHS() {

        // Class Loader table
        if (on12) {
            clTable = new Hashtable();
        }
    }

    public void showHelp(String target){

        mainHB.setDisplayed(true);
        mainHB.setCurrentID(target);
    }

    public static TSHelpSet getInstance() {
        if(instance == null){
            instance = new TSHelpSet();
        }
        return instance;
    }
}
