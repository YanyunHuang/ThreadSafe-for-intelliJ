package intellij;

import com.intellij.ide.DataManager;
import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;

import java.util.concurrent.Callable;

/**
 * Created by huangyanyun on 7/14/17.
 */
public class TSProjectBuilder implements Callable {

    private Project project;
    public TSProjectBuilder(Project pro){
        this.project = pro;
    }
    @Override
    public Object call() throws Exception {
        ActionManager manager = ActionManager.getInstance();
        AnAction callHierarchy = manager.getAction("CompileDirty");
        DataContext dataContext = DataManager.getInstance().getDataContext(
                FileEditorManager.getInstance(project).getSelectedTextEditor().getContentComponent());
        callHierarchy.actionPerformed(AnActionEvent.createFromAnAction(
                callHierarchy, null, ActionPlaces.UNKNOWN, dataContext));


        return null;
    }
}
