package intellij;

import com.intellij.openapi.editor.Document;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.fileEditor.impl.FileDocumentManagerImpl;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleManager;
import com.intellij.openapi.vfs.VfsUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.JavaPsiFacade;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiField;
import com.intellij.psi.PsiFile;
import com.intellij.psi.impl.source.PsiJavaFileImpl;
import com.intellij.psi.search.GlobalSearchScope;
import manager.PluginManager;
import model.xml.TSLocation;

import java.lang.reflect.Field;

/**
 * Created by huangyanyun on 7/23/17.
 */
public class Tools {

    public static String getClassFile(String pkgName) {

        return pkgName;

//        GlobalSearchScope scope = GlobalSearchScope.allScope (PluginManager.getInstance().getCurrentPro());
//        PsiClass targetClass = JavaPsiFacade.getInstance(PluginManager.getInstance().getCurrentPro()).
//                findClass(pkgName, scope);
//        targetClass.getAllFields()[0].getNameIdentifier();
//        return targetClass.getContainingFile().getVirtualFile().getPath();
    }

    public static String findField(String className, String name) {



        GlobalSearchScope scope = GlobalSearchScope.allScope (PluginManager.getInstance().getCurrentPro());
        PsiClass targetClass = JavaPsiFacade.getInstance(PluginManager.getInstance().getCurrentPro()).
                findClass(className, scope);
        targetClass.getAllFields()[0].getNameIdentifier();

        VirtualFile vf = targetClass.getContainingFile().getVirtualFile();
        FileDocumentManagerImpl impl = (FileDocumentManagerImpl) FileDocumentManager.getInstance();
        Document document = impl.getDocument(vf);


        PsiField key = targetClass.findFieldByName(name, false);
        int line1 = key.getStartOffsetInParent();
        int line2 = key.getTextOffset();

        return (document.getLineNumber(line2) + "");
    }

    public static int getFieldLineNumber(Document document, PsiFile psiFile, String name) {
        if((document == null) || (psiFile == null) || (name == null)){
            return 1;
        }
        PsiField key = (((PsiJavaFileImpl)psiFile).getClasses())[0].findFieldByName(name, false);
        int line = document.getLineNumber(key.getTextOffset());
        return line;
    }

    public static int getFieldLineNumber(TSLocation tsLocation) {
        FileDocumentManagerImpl impl = (FileDocumentManagerImpl) FileDocumentManager.getInstance();
//        GlobalSearchScope scope = GlobalSearchScope.allScope (PluginManager.getInstance().getCurrentPro());

        GlobalSearchScope scope = GlobalSearchScope.moduleScope(tsLocation.getModuleName());
        PsiClass targetClass = JavaPsiFacade.getInstance(PluginManager.getInstance().getCurrentPro()).
                findClass(tsLocation.getClassName(), scope);
        VirtualFile vf = targetClass.getContainingFile().getVirtualFile();
        Document document = impl.getDocument(vf);
        return getFieldLineNumber(document, targetClass.getContainingFile(), ((model.xml.Field)tsLocation).getName());
    }
}
