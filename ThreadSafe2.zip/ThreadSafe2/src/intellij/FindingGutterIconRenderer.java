package intellij;

import com.intellij.openapi.editor.markup.GutterIconRenderer;
import com.intellij.openapi.util.IconLoader;
import model.xml.enums.Severity;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * Created by huangyanyun on 7/15/17.
 */
public class FindingGutterIconRenderer extends GutterIconRenderer {

    boolean isLocation = false;
    private Severity severity;

    public FindingGutterIconRenderer(boolean isLocation, Severity severity){

        this.isLocation = isLocation;
        this.severity = severity;
    }

    @Override
    public boolean equals(Object obj) {
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }

    @NotNull
    @Override
    public Icon getIcon() {
        if(isLocation){
            switch(severity){
                case Blocker:
                    return IconLoader.findIcon("/icons/obj16/blocker.png");
                case Critical:
                    return IconLoader.findIcon("/icons/obj16/critical.png");
                case Major:
                    return IconLoader.findIcon("/icons/obj16/major.png");
                case Minor:
                    return IconLoader.findIcon("/icons/obj16/minor.png");
                case Info:
                    return IconLoader.findIcon("/icons/obj16/info.png");
                default:
                    return IconLoader.findIcon("/icons/obj16/blocker.png");
            }
        }else{
            return IconLoader.findIcon("/icons/obj16/location.gif");
        }
    }
}
