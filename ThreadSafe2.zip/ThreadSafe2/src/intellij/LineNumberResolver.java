package intellij;

import com.intellij.psi.PsiField;
import com.intellij.lang.ASTNode;
import com.intellij.util.ReflectionUtil;
import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyClassLoader.ClassCollector;
import manager.PluginManager;

import java.lang.reflect.Field;

/**
 * Created by huangyanyun on 7/23/17.
 */
public class LineNumberResolver {

    public static String findField(String className, String name) {
        String result = "";
        try {
//            FieldAnnotation.
//            psiElement = IdeaUtilImpl.findAnonymousClassPsiElement(psiFile, bug.getInstance(), psiFile.getProject());
//
//            final ClassCollector cc;
//            cc = new ClassCollector(PluginManager.getInstance().getCurrentPro());
//            cc.getClass();
//
//            ClassCollector.
//
            Class targetClass = Class.forName(className);
//            targetClass.getResource()
//            PsiField field =
            Field field = ReflectionUtil.findField(targetClass, null, name);
//            result = field
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

//

        return result;
    }
}
